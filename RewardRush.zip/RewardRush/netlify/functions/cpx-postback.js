/* ============================================================
   FILE: netlify/functions/cpx-postback.js

   Receives server-to-server postbacks from CPX Research whenever
   a user completes (status=1) or a completion is reversed /
   charged back (status=2) on a survey.

   Deploy URL (must match what you configure in the CPX Research
   dashboard, "Postback URL"):
   https://rewardsrush.netlify.app/.netlify/functions/cpx-postback

   CPX Research calls this with GET query parameters (their SDK
   always appends these placeholders):
     status        1 = confirmed reward, 2 = reversed/chargeback
     trans_id      unique transaction id for this completion
     user_id       the extUserId we passed CPX (the Firebase uid,
                   set in js/survey.js as window.cpxCnf.extUserId)
     offer_id      the survey/offer id
     amount_local  reward amount in local currency (₹) — this is
                   what we credit, since 1 Reward Rush Coin = ₹1
     amount_usd    reward amount in USD (informational only)
     hash          secure hash CPX computed so we can verify the
                   request really came from them

   Security: CPX Research's secure hash scheme is
     hash = md5(trans_id + "-" + <your CPX Secure Hash key>)
   The key is configured once in the CPX dashboard and stored here
   as the CPX_SECURE_HASH environment variable — never hardcoded.

   Duplicate protection: every trans_id is recorded under
   users/{uid}/completedSurveys/{trans_id}. If we see the same
   trans_id again with status=1, we do NOT credit twice.
   ============================================================ */

const crypto = require('crypto');
const { getDb } = require('./_lib/firebaseAdmin');
const { json, text, handlePreflight } = require('./_lib/http');

function verifySecureHash(transId, providedHash) {
    const secureHashKey = process.env.CPX_SECURE_HASH;
    if (!secureHashKey) {
        // Fail closed: if the key isn't configured we cannot verify
        // authenticity, so we reject rather than silently trust it.
        return false;
    }
    if (!providedHash) return false;
    const expected = crypto.createHash('md5').update(`${transId}-${secureHashKey}`).digest('hex');
    return expected.toLowerCase() === String(providedHash).toLowerCase();
}

exports.handler = async (event) => {
    const preflight = handlePreflight(event);
    if (preflight) return preflight;

    try {
        const params = event.httpMethod === 'POST'
            ? { ...(event.queryStringParameters || {}), ...(safeParseBody(event.body)) }
            : (event.queryStringParameters || {});

        const {
            status,
            trans_id: transId,
            user_id: userId,
            offer_id: offerId,
            amount_local: amountLocalRaw,
            amount_usd: amountUsdRaw,
            hash
        } = params;

        if (!transId || !userId || !status) {
            return text(400, 'MISSING_PARAMS');
        }

        if (!verifySecureHash(transId, hash)) {
            return text(403, 'INVALID_HASH');
        }

        const db = getDb();
        const userRef = db.ref(`users/${userId}`);
        const userSnap = await userRef.once('value');
        if (!userSnap.exists()) {
            return text(404, 'USER_NOT_FOUND');
        }

        const rewardAmount = parseFloat(amountLocalRaw) || 0;
        const amountUsd = parseFloat(amountUsdRaw) || 0;
        const isReversal = String(status) === '2';
        const completionRef = db.ref(`users/${userId}/completedSurveys/${transId}`);
        const completionSnap = await completionRef.once('value');
        const existing = completionSnap.val();

        if (!isReversal) {
            // ---- Normal completion (status 1) ----
            if (existing && existing.status === 'CREDITED') {
                // Already credited for this trans_id — do not double pay.
                return json(200, { success: true, alreadyCredited: true });
            }

            let newBalance = null;
            await db.ref(`users/${userId}/balance`).transaction((current) => (current || 0) + rewardAmount);
            const balanceSnap = await db.ref(`users/${userId}/balance`).once('value');
            newBalance = balanceSnap.val();

            await completionRef.set({
                offerId: offerId || null,
                reward: rewardAmount,
                amountUsd,
                status: 'CREDITED',
                timestamp: Date.now()
            });

            const txRef = db.ref('transactions').push();
            await txRef.set({
                uid: userId,
                amount: rewardAmount,
                type: 'SURVEY_REWARD',
                description: `CPX Survey reward${offerId ? ' for offer ' + offerId : ''} (${transId})`,
                timestamp: Date.now(),
                status: 'SUCCESS'
            });

            return json(200, {
                success: true,
                message: 'Survey reward credited',
                newBalance,
                rewardAmount
            });
        }

        // ---- Reversal / chargeback (status 2) ----
        if (!existing || existing.status !== 'CREDITED') {
            // Nothing to reverse — just record it so we never double-process.
            await completionRef.set({
                offerId: offerId || null,
                reward: rewardAmount,
                amountUsd,
                status: 'REVERSED_NOOP',
                timestamp: Date.now()
            });
            return json(200, { success: true, reversed: false, message: 'No prior credit to reverse' });
        }

        const reversedAmount = existing.reward || rewardAmount;
        await db.ref(`users/${userId}/balance`).transaction((current) => (current || 0) - reversedAmount);
        const balanceSnap = await db.ref(`users/${userId}/balance`).once('value');
        const newBalance = balanceSnap.val();

        await completionRef.update({ status: 'REVERSED', reversedAt: Date.now() });

        const txRef = db.ref('transactions').push();
        await txRef.set({
            uid: userId,
            amount: -reversedAmount,
            type: 'SURVEY_REVERSAL',
            description: `CPX Survey reward reversed${offerId ? ' for offer ' + offerId : ''} (${transId})`,
            timestamp: Date.now(),
            status: 'SUCCESS'
        });

        return json(200, { success: true, reversed: true, newBalance });
    } catch (error) {
        console.error('CPX Postback Error:', error);
        // CPX Research expects a 200 with a parseable body even on our
        // internal errors would be wrong — real errors should surface
        // as non-200 so CPX's dashboard flags the postback as failing.
        return text(500, 'ERROR: ' + error.message);
    }
};

function safeParseBody(body) {
    if (!body) return {};
    try { return JSON.parse(body); } catch (e) { return {}; }
}
