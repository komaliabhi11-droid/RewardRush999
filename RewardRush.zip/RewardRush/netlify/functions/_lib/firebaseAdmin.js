/* ============================================================
   FILE: netlify/functions/_lib/firebaseAdmin.js
   Shared firebase-admin bootstrap for every Netlify function.
   Reads credentials from Netlify Environment Variables ONLY —
   nothing is hardcoded here. Uses the Realtime Database (same
   database the client app already reads/writes), not Firestore.
   ============================================================ */

const admin = require('firebase-admin');

function getAdminApp() {
    if (admin.apps.length) return admin.app();

    const projectId = process.env.FIREBASE_PROJECT_ID;
    const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
    const rawPrivateKey = process.env.FIREBASE_PRIVATE_KEY;
    const databaseURL = process.env.FIREBASE_DATABASE_URL;

    if (!projectId || !clientEmail || !rawPrivateKey || !databaseURL) {
        throw new Error(
            'Missing Firebase Admin environment variables. Set FIREBASE_PROJECT_ID, ' +
            'FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY and FIREBASE_DATABASE_URL in Netlify.'
        );
    }

    const privateKey = rawPrivateKey.replace(/\\n/g, '\n');

    return admin.initializeApp({
        credential: admin.credential.cert({ projectId, clientEmail, privateKey }),
        databaseURL
    });
}

function getDb() {
    return getAdminApp().database();
}

function getAdminAuth() {
    return getAdminApp().auth();
}

module.exports = { getAdminApp, getDb, getAdminAuth };
