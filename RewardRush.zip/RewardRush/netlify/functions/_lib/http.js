/* ============================================================
   FILE: netlify/functions/_lib/http.js
   Small shared helpers for consistent JSON responses + CORS.
   ============================================================ */

const CORS_HEADERS = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-admin-key',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
};

function json(statusCode, body) {
    return {
        statusCode,
        headers: { 'Content-Type': 'application/json', ...CORS_HEADERS },
        body: JSON.stringify(body)
    };
}

function text(statusCode, body) {
    return {
        statusCode,
        headers: { 'Content-Type': 'text/plain', ...CORS_HEADERS },
        body: String(body)
    };
}

function handlePreflight(event) {
    if (event.httpMethod === 'OPTIONS') {
        return { statusCode: 204, headers: CORS_HEADERS, body: '' };
    }
    return null;
}

module.exports = { json, text, handlePreflight, CORS_HEADERS };
