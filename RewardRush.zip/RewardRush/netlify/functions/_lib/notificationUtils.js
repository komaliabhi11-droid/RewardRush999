function normalizeNotificationsList(data) {
    if (!data) return [];
    const list = Object.keys(data).map(id => ({ id, ...data[id] }));
    list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    return list;
}

module.exports = { normalizeNotificationsList };
