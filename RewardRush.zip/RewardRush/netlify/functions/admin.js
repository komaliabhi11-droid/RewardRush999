/* ============================================================
   FILE: netlify/functions/admin.js

   Backend for the admin panel (admin.html + js/admin.js).
   Every request must include BOTH:
     1. Authorization: Bearer <Firebase ID token> of an account
        listed in ADMIN_ALLOWED_EMAILS, and
     2. header x-admin-key: <ADMIN_API_KEY>
   as two independent layers of protection.

   Body: { action: "...", ...actionSpecificFields }

   Supported actions:
     listWithdrawals              -> { withdrawals: [...] }
     approveWithdrawal            { withdrawalId }
     rejectWithdrawal             { withdrawalId, reason? }  (refunds the user)
     addCoins                     { uid, amount, reason? }
     removeCoins                  { uid, amount, reason? }
     sendNotification             { title, message, target? }  (target uid, or omit for broadcast)
     listUsers                    -> { users: [...] }
   ============================================================ */

const { getDb, getAdminAuth } = require('./_lib/firebaseAdmin');
const { json, handlePreflight } = require('./_lib/http');

async function requireAdmin(event) {
    const adminKey = event.headers['x-admin-key'] || event.headers['X-Admin-Key'];
    if (!process.env.ADMIN_API_KEY || adminKey !== process.env.ADMIN_API_KEY) {
        return { ok: false, response: json(401, { success: false, error: 'Invalid admin key' }) };
    }

    const authHeader = event.headers.authorization || event.headers.Authorization || '';
    const idToken = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
    if (!idToken) {
        return { ok: false, response: json(401, { success: false, error: 'Missing Authorization bearer token' }) };
    }

    let decoded;
    try {
        decoded = await getAdminAuth().verifyIdToken(idToken);
    } catch (e) {
        return { ok: false, response: json(401, { success: false, error: 'Invalid or expired token' }) };
    }

    const allowList = (process.env.ADMIN_ALLOWED_EMAILS || '')
        .split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
    const email = (decoded.email || '').toLowerCase();
    const isAllowed = allowList.includes(email) || allowList.includes(decoded.uid);

    if (!isAllowed) {
        return { ok: false, response: json(403, { success: false, error: 'Not an admin account' }) };
    }

    return { ok: true, uid: decoded.uid, email: decoded.email };
}

exports.handler = async (event) => {
    const preflight = handlePreflight(event);
    if (preflight) return preflight;

    if (event.httpMethod !== 'POST') {
        return json(405, { success: false, error: 'Method not allowed' });
    }

    const authCheck = await requireAdmin(event);
    if (!authCheck.ok) return authCheck.response;

    try {
        const body = JSON.parse(event.body || '{}');
        const db = getDb();

        switch (body.action) {
            case 'listWithdrawals': {
                const snap = await db.ref('withdrawals').once('value');
                const data = snap.val() || {};
                const withdrawals = Object.keys(data)
                    .map(id => ({ id, ...data[id] }))
                    .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
                return json(200, { success: true, withdrawals });
            }

            case 'listUsers': {
                const snap = await db.ref('users').once('value');
                const data = snap.val() || {};
                const users = Object.keys(data).map(uid => ({
                    uid,
                    fullName: (data[uid].personalDetails && data[uid].personalDetails.fullName) || '',
                    email: (data[uid].personalDetails && data[uid].personalDetails.email) || '',
                    balance: data[uid].balance || 0,
                    referralCode: data[uid].referralCode || ''
                }));
                return json(200, { success: true, users });
            }

            case 'approveWithdrawal': {
                const { withdrawalId } = body;
                if (!withdrawalId) return json(400, { success: false, error: 'withdrawalId required' });
                const wdRef = db.ref(`withdrawals/${withdrawalId}`);
                const wdSnap = await wdRef.once('value');
                const withdrawal = wdSnap.val();
                if (!withdrawal) return json(404, { success: false, error: 'Withdrawal not found' });
                if (withdrawal.status !== 'PENDING') {
                    return json(400, { success: false, error: `Withdrawal already ${withdrawal.status}` });
                }
                await wdRef.update({ status: 'APPROVED', processedAt: Date.now(), processedBy: authCheck.email });
                if (withdrawal.transactionId) {
                    await db.ref(`transactions/${withdrawal.transactionId}`).update({ status: 'SUCCESS' });
                }
                await pushNotification(db, {
                    title: 'Withdrawal Approved',
                    message: `Your withdrawal of ₹${withdrawal.amount} has been approved and sent to ${withdrawal.upiId}.`,
                    target: withdrawal.uid
                });
                return json(200, { success: true });
            }

            case 'rejectWithdrawal': {
                const { withdrawalId, reason } = body;
                if (!withdrawalId) return json(400, { success: false, error: 'withdrawalId required' });
                const wdRef = db.ref(`withdrawals/${withdrawalId}`);
                const wdSnap = await wdRef.once('value');
                const withdrawal = wdSnap.val();
                if (!withdrawal) return json(404, { success: false, error: 'Withdrawal not found' });
                if (withdrawal.status !== 'PENDING') {
                    return json(400, { success: false, error: `Withdrawal already ${withdrawal.status}` });
                }

                // Refund the user's balance since the withdrawal did not go through.
                await db.ref(`users/${withdrawal.uid}/balance`).transaction((current) => (current || 0) + withdrawal.amount);

                await wdRef.update({
                    status: 'REJECTED',
                    processedAt: Date.now(),
                    processedBy: authCheck.email,
                    reason: reason || ''
                });
                if (withdrawal.transactionId) {
                    await db.ref(`transactions/${withdrawal.transactionId}`).update({ status: 'FAILED' });
                }
                await pushNotification(db, {
                    title: 'Withdrawal Rejected',
                    message: `Your withdrawal of ₹${withdrawal.amount} was rejected${reason ? ': ' + reason : '.'} The amount has been refunded to your balance.`,
                    target: withdrawal.uid
                });
                return json(200, { success: true });
            }

            case 'addCoins': {
                const { uid, amount, reason } = body;
                const amt = parseFloat(amount);
                if (!uid || !amt || amt <= 0) return json(400, { success: false, error: 'uid and positive amount required' });
                const result = await db.ref(`users/${uid}/balance`).transaction((current) => (current || 0) + amt);
                if (!result.committed) return json(500, { success: false, error: 'Could not update balance' });
                await db.ref('transactions').push().set({
                    uid, amount: amt, type: 'ADMIN_CREDIT',
                    description: reason || 'Coins added by admin',
                    timestamp: Date.now(), status: 'SUCCESS'
                });
                return json(200, { success: true, newBalance: result.snapshot.val() });
            }

            case 'removeCoins': {
                const { uid, amount, reason } = body;
                const amt = parseFloat(amount);
                if (!uid || !amt || amt <= 0) return json(400, { success: false, error: 'uid and positive amount required' });
                const result = await db.ref(`users/${uid}/balance`).transaction((current) => Math.max(0, (current || 0) - amt));
                if (!result.committed) return json(500, { success: false, error: 'Could not update balance' });
                await db.ref('transactions').push().set({
                    uid, amount: -amt, type: 'ADMIN_DEBIT',
                    description: reason || 'Coins removed by admin',
                    timestamp: Date.now(), status: 'SUCCESS'
                });
                return json(200, { success: true, newBalance: result.snapshot.val() });
            }

            case 'sendNotification': {
                const { title, message, target } = body;
                if (!title || !message) return json(400, { success: false, error: 'title and message required' });
                const notifRef = await pushNotification(db, { title, message, target: target || null });
                return json(200, { success: true, notificationId: notifRef.key });
            }

            default:
                return json(400, { success: false, error: `Unknown action: ${body.action}` });
        }
    } catch (error) {
        console.error('Admin Function Error:', error);
        return json(500, { success: false, error: error.message });
    }
};

async function pushNotification(db, { title, message, target }) {
    const ref = db.ref('notifications').push();
    await ref.set({
        title,
        message,
        target: target || null, // null = broadcast to all users
        createdAt: Date.now()
    });
    return ref;
}
