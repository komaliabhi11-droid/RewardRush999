/* ============================================================
   FILE: netlify/functions/notifications.js

   The live notification bell in app.js keeps using the Realtime
   Database's onValue listener directly (that already worked, so
   it wasn't touched). This function is the secure server-side
   companion for the two things that shouldn't happen straight
   from the client:

     GET  ?uid=<uid>              -> notifications relevant to that
                                      user (broadcasts + targeted),
                                      requires the user's own
                                      Firebase ID token.
     POST { action: "markRead",
            notificationId }      -> records a per-user read flag
                                      under users/{uid}/readNotifications

   Sending a new notification is an admin action and lives in
   netlify/functions/admin.js ("sendNotification").
   ============================================================ */

const { getDb, getAdminAuth } = require('./_lib/firebaseAdmin');
const { json, handlePreflight } = require('./_lib/http');
const { normalizeNotificationsList } = require('./_lib/notificationUtils');

async function verifyCaller(event) {
    const authHeader = event.headers.authorization || event.headers.Authorization || '';
    const idToken = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
    if (!idToken) return null;
    try {
        return await getAdminAuth().verifyIdToken(idToken);
    } catch (e) {
        return null;
    }
}

exports.handler = async (event) => {
    const preflight = handlePreflight(event);
    if (preflight) return preflight;

    const decoded = await verifyCaller(event);
    if (!decoded) {
        return json(401, { success: false, error: 'Missing or invalid Authorization bearer token' });
    }

    const db = getDb();

    if (event.httpMethod === 'GET') {
        const snap = await db.ref('notifications').once('value');
        const all = normalizeNotificationsList(snap.val());
        const relevant = all.filter(n => !n.target || n.target === decoded.uid);
        return json(200, { success: true, notifications: relevant });
    }

    if (event.httpMethod === 'POST') {
        try {
            const body = JSON.parse(event.body || '{}');
            if (body.action === 'markRead' && body.notificationId) {
                await db.ref(`users/${decoded.uid}/readNotifications/${body.notificationId}`).set(true);
                return json(200, { success: true });
            }
            return json(400, { success: false, error: 'Unsupported action' });
        } catch (error) {
            console.error('Notifications Function Error:', error);
            return json(500, { success: false, error: error.message });
        }
    }

    return json(405, { success: false, error: 'Method not allowed' });
};
