/* ============================================================
   FILE: netlify/functions/withdraw.js

   Receives withdrawal requests from js/withdraw.js (called from
   the existing withdraw modal in app.js — same UI, same flow).

   - Verifies the caller's Firebase ID token (Authorization: Bearer)
     so nobody can withdraw on behalf of another uid.
   - Re-reads the balance server-side (source of truth) and
     atomically deducts it, refusing if funds are insufficient —
     closing the "edit the request in devtools" hole the original
     client-only implementation had.
   - Writes both:
       withdrawals/{id}   -> what the (new) admin panel lists/approves
       transactions/{id}  -> same shape the existing history.js /
                              TransactionsTab already reads, so the
                              user's history keeps working unchanged.
   - Status starts PENDING; netlify/functions/admin.js moves it to
     APPROVED or REJECTED (rejection refunds the balance).
   ============================================================ */

const { getDb, getAdminAuth } = require('./_lib/firebaseAdmin');
const { json, handlePreflight } = require('./_lib/http');

exports.handler = async (event) => {
    const preflight = handlePreflight(event);
    if (preflight) return preflight;

    if (event.httpMethod !== 'POST') {
        return json(405, { success: false, error: 'Method not allowed' });
    }

    try {
        const authHeader = event.headers.authorization || event.headers.Authorization || '';
        const idToken = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
        if (!idToken) {
            return json(401, { success: false, error: 'Missing Authorization bearer token' });
        }

        const decoded = await getAdminAuth().verifyIdToken(idToken);
        const uid = decoded.uid;

        const body = JSON.parse(event.body || '{}');
        const amount = parseFloat(body.amount);
        const method = body.method || 'UPI';
        const upiId = (body.upiId || '').trim();
        const fullName = (body.fullName || '').trim();
        const phone = (body.phone || '').trim();

        if (!amount || amount <= 0) {
            return json(400, { success: false, error: 'Invalid withdrawal amount' });
        }
        if (!upiId || !fullName || !phone) {
            return json(400, { success: false, error: 'Please complete your payment details before withdrawing.' });
        }

        const db = getDb();
        const balanceRef = db.ref(`users/${uid}/balance`);

        let insufficientFunds = false;
        const txResult = await balanceRef.transaction((current) => {
            const currentBalance = current || 0;
            if (currentBalance < amount) {
                insufficientFunds = true;
                return current; // abort-equivalent: leave unchanged
            }
            return currentBalance - amount;
        });

        if (insufficientFunds) {
            return json(400, { success: false, error: 'Insufficient balance!' });
        }
        if (!txResult.committed) {
            return json(500, { success: false, error: 'Could not update balance, please try again.' });
        }

        const newBalance = txResult.snapshot.val();
        const now = Date.now();

        const txRef = db.ref('transactions').push();
        await txRef.set({
            uid,
            amount: -amount,
            type: 'WITHDRAWAL',
            description: `Withdrawal via ${method}`,
            timestamp: now,
            status: 'PENDING'
        });

        const withdrawalRef = db.ref('withdrawals').push();
        await withdrawalRef.set({
            uid,
            amount,
            method,
            upiId,
            fullName,
            phone,
            status: 'PENDING',
            transactionId: txRef.key,
            createdAt: now
        });

        return json(200, {
            success: true,
            newBalance,
            withdrawalId: withdrawalRef.key,
            transactionId: txRef.key
        });
    } catch (error) {
        console.error('Withdraw Function Error:', error);
        return json(500, { success: false, error: error.message });
    }
};
