# Reward Rush

Production-ready Netlify project generated from your original single-file
`index.html`. Every screen, feature and piece of UI you had is unchanged —
the code was **split into files**, not rewritten. Please read the
"Important — please read" section below before deploying; two things in
your spec didn't match what was actually in the uploaded file, and I want
you to know exactly what I did about them rather than silently guessing.

## ⚠️ Important — please read

**1. This app uses the Firebase Realtime Database, not Firestore.**
Your uploaded `index.html` initializes `getDatabase()` and reads/writes
`users/`, `transactions/`, `offers/`, `branding/`, `notifications/` as
Realtime Database paths, everywhere, including the commented-out Cloud
Function at the bottom of the file. There is no Firestore code anywhere in
your original app. Your `firebaseConfig` also has a `databaseURL`, which is
a Realtime Database field. Switching this project to Firestore would mean
throwing away your existing data model and rewriting every screen — the
opposite of "don't remove any feature." So this project keeps using the
Realtime Database end-to-end, on both the client (`js/*.js`) and the new
backend (`netlify/functions/*.js`, via `firebase-admin`). If you actually
do have a separate Firestore-based backend somewhere that this file didn't
show, let me know and I'll wire the functions to that instead.

**2. There was no existing admin panel in the file you uploaded.**
I searched the whole file for it — there's no admin route, no admin
component, no admin UI of any kind. So there was nothing "existing" for me
to reuse. Rather than leave `admin.js` as a stub (which you also asked me
not to do), I built a real, working admin panel — `admin.html` +
`js/admin.js` — using the exact same colors/fonts/card styles as the rest
of the app, so it looks native. **It's a completely separate page that
never touches `index.html`.** If you have an admin panel elsewhere (a
different file, a different tool), just don't deploy `admin.html` and
point that existing panel at the same `netlify/functions/admin.js` backend
— it's a plain JSON API, not tied to this specific frontend.

Everything else below was built exactly to your spec.

## What changed vs. the original file

- **UI/UX: untouched.** Every component, every Tailwind class, every piece
  of copy is byte-for-byte what you had — just moved into `js/*.js` files
  and loaded with `<script type="text/babel" src="...">` tags in the
  right order, so the browser still does the exact same in-browser Babel
  transform it always did. No build step, no bundler, nothing to break.
- **Auth, withdrawal, and notifications logic** were lightly refactored
  into `js/auth.js`, `js/withdraw.js`, `js/notifications.js` as reusable
  functions (same Firebase calls, same behavior) so `js/app.js` stays
  readable and matches the file structure you asked for.
- **Withdrawals now go through a secure backend.** Originally, the browser
  deducted the balance and wrote the transaction directly — which means
  anyone could edit the request in devtools and withdraw more than they
  actually have. `js/withdraw.js` now calls
  `netlify/functions/withdraw.js`, which re-checks the real balance
  server-side (via `firebase-admin`) before touching anything. The modal,
  the validation messages, and the success animation are all identical to
  before — only what happens on the server changed.
- **CPX Research postbacks, which your file didn't actually implement
  server-side** (the Cloud Function at the bottom was commented-out
  reference code, never deployed), now have a real, working
  implementation in `netlify/functions/cpx-postback.js` — see below.

## Project structure

```
RewardRush/
├── index.html                  Main app (unchanged UI)
├── admin.html                  New admin panel (separate page)
├── package.json
├── netlify.toml
├── database.rules.json         Realtime Database security rules
├── .env.example
├── css/style.css
├── js/
│   ├── firebase.js             Firebase web config + shared instances
│   ├── auth.js                 Login/register/Google/logout
│   ├── app.js                  Main React app (state, routing, AUTH + dashboard shell)
│   ├── dashboard.js             Tasks placeholder + Daily Check-In
│   ├── survey.js                CPX Research survey wall
│   ├── wallet.js                Offers & Spin tab
│   ├── withdraw.js              Withdrawal validation + backend call
│   ├── history.js               Transaction history tab
│   ├── notifications.js         Notification list helper
│   ├── profile.js               Profile + personal/address/payout views
│   ├── settings.js              AI support desk
│   └── admin.js                 New admin panel app
├── assets/
│   ├── logo.png
│   ├── icons/ banners/ images/  (empty, ready for your assets)
└── netlify/functions/
    ├── _lib/                   Shared firebase-admin + HTTP helpers
    ├── cpx-postback.js
    ├── withdraw.js
    ├── admin.js
    └── notifications.js
```

No `package-lock.json` is included — I don't have network/npm access in
this environment to generate a real one, and a fabricated lockfile could
break `npm ci`. Running `npm install` once (locally or automatically as
part of the Netlify build, see `netlify.toml`) will generate a correct one
for you to commit.

## Setting up Firebase

1. **Realtime Database**: in the Firebase console, deploy
   `database.rules.json` (Realtime Database → Rules → paste the file's
   contents → Publish). It keeps `users/{uid}` readable/writable only by
   that user, keeps `branding` public-read, and — importantly — locks the
   new `withdrawals` node to **no client access at all**, since it's only
   ever written by the Netlify functions using the Admin SDK (which
   bypasses these rules by design).
2. **Service account** for the backend: Project settings → Service
   accounts → Generate new private key. Put the three fields
   (`project_id`, `client_email`, `private_key`) into Netlify's
   environment variables as shown in `.env.example`.
3. **Enable the sign-in methods** you use (Email/Password, Google) if not
   already on, under Authentication → Sign-in method.

## Setting up CPX Research

Your CPX app id (`34407`) and `extUserId` binding were already correct in
`js/survey.js` — untouched. What's new is the postback handling:

1. In the CPX Research dashboard, set your **Postback URL** to:
   ```
   https://rewardsrush.netlify.app/.netlify/functions/cpx-postback
   ```
2. Copy the **Secure Hash** key CPX gives you and set it as `CPX_SECURE_HASH`
   in Netlify's environment variables. `cpx-postback.js` verifies every
   incoming request with `md5(trans_id + "-" + CPX_SECURE_HASH)` and
   rejects anything that doesn't match — so nobody can fake a completion
   and hand themselves free coins.
3. The function credits `amount_local` (1 Reward Rush Coin = ₹1, matching
   your app's rule) to `users/{user_id}/balance`, records
   `users/{user_id}/completedSurveys/{trans_id}` so the same `trans_id`
   can never be paid twice, writes a `transactions/` entry, and returns
   HTTP 200. It also handles CPX's `status=2` reversal/chargeback callback
   by deducting the coins back out if — and only if — that `trans_id` was
   actually credited before.

## Setting up the admin panel

1. Set `ADMIN_ALLOWED_EMAILS` (comma-separated) and `ADMIN_API_KEY`
   (a long random string) in Netlify's environment variables.
2. Create/promote a normal Firebase Auth account for yourself with one of
   those emails.
3. Visit `/admin.html`, sign in with that account, then enter the
   `ADMIN_API_KEY` when prompted (this is a second factor — even if
   someone guesses/phishes an admin's Firebase login, they can't call
   `netlify/functions/admin.js` without also knowing this key).
4. From there you can approve/reject withdrawals (rejecting automatically
   refunds the user), add/remove coins from any user's balance, browse
   users, and send notifications (broadcast to everyone or targeted to one
   `uid`) — all backed by `netlify/functions/admin.js`.

## Deploying

1. Push this folder to a Git repo, or drag-and-drop it into Netlify.
2. In Netlify: Site settings → Environment variables → add everything from
   `.env.example` with your real values.
3. Deploy. `netlify.toml` runs `npm install` (so `firebase-admin` is
   available to the functions bundler) and publishes the project root as
   a static site, with `netlify/functions` as the Functions directory.
4. Confirm `https://rewardsrush.netlify.app/.netlify/functions/cpx-postback`
   responds (a `GET` with no params should return `400 MISSING_PARAMS` —
   that's correct, it means the function is live and validating input).

## Local development

```bash
npm install
npx netlify dev
```

This serves `index.html`/`admin.html` and proxies `/.netlify/functions/*`
to your local functions, reading env vars from a local `.env` file (never
commit that file — `.env.example` is the template, `.gitignore` already
excludes `.env`).
