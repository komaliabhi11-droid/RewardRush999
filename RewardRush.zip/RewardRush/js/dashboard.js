/* ============================================================
   FILE: js/dashboard.js
   Tasks placeholder + Daily Check-In (Campaigns) view.
   ============================================================ */

                                                /* ─── TASKS PLACEHOLDER ─── */
                                                function TasksPlaceholder() {
                                                    return ( <
                                                        div className = "py-10 text-center" >
                                                        <
                                                        span className = "material-symbols-rounded text-6xl text-neutral-600" >
                                                        task_alt < /span> <
                                                        h3 className = "text-xl font-bold text-white mt-4" > Tasks Section <
                                                        /h3> <
                                                        p className = "text-xs text-brand-grayMuted mt-2" > Your allocated
                                                        workflow tasks will be populated here. < /p> <
                                                        /div>
                                                    );
                                                }

                                                /* ─── DAILY CHECK-IN VIEW ─── */
                                                function DailyCheckInView({ lastClaimedDay, lastClaimTimestamp,
                                                        offersCompletedCount, lastOfferTimestamp, onClaim }) {
                                                    const daysData = [
                                                        { day: 1, reward: 1.0 },
                                                        { day: 2, reward: 1.5 },
                                                        { day: 3, reward: 2.0 },
                                                        { day: 4, reward: 2.5 },
                                                        { day: 5, reward: 3.0 },
                                                        { day: 6, reward: 4.0 },
                                                        { day: 7, reward: 5.0 }
                                                    ];
                                                    const [countdownText, setCountdownText] = useState('');
                                                    const intervalRef = useRef(null);

                                                    useEffect(() => {
                                                        const calc = () => {
                                                            const now = Date.now();
                                                            const diff = now - lastClaimTimestamp;
                                                            const limit = 24 * 60 * 60 * 1000;
                                                            if (lastClaimTimestamp > 0 && diff < limit) {
                                                                const rem = limit - diff;
                                                                const h = Math.floor(rem / (3600 * 1000));
                                                                const m = Math.floor((rem % (3600 * 1000)) / (60 *
                                                                1000));
                                                                const s = Math.floor((rem % (60 * 1000)) / 1000);
                                                                setCountdownText(
                                                                    `Next unlock in: ${h}h ${m}m ${s}s`);
                                                            } else {
                                                                setCountdownText('');
                                                            }
                                                        };
                                                        calc();
                                                        intervalRef.current = setInterval(calc, 1000);
                                                        return () => {
                                                            if (intervalRef.current) clearInterval(intervalRef
                                                                .current);
                                                        };
                                                    }, [lastClaimTimestamp]);

                                                    const now = Date.now();
                                                    const hasOfferInPast24h = (now - lastOfferTimestamp <= 24 * 60 * 60 *
                                                        1000) && offersCompletedCount > 0;

                                                    return ( <
                                                        div className = "py-4 px-2 space-y-6 flex flex-col items-center justify-center min-h-[60vh]" >
                                                        <
                                                        div className = "text-center" >
                                                        <
                                                        h2 className = "text-3xl font-extrabold tracking-tight text-neutral-100 mb-1" >
                                                        Daily Rewards < /h2> {
                                                            countdownText && ( <
                                                                p className = "text-xs font-mono text-brand-orangeLight animate-pulse bg-neutral-900/80 px-3 py-1 rounded-full border border-brand-orange/20 inline-block mt-1" >
                                                                { countdownText } < /p>
                                                            )
                                                        } <
                                                        /div> <
                                                        div className = "grid grid-cols-3 gap-x-8 gap-y-6 max-w-sm justify-center" > {
                                                            daysData.map((item) => {
                                                                const isClaimed = item.day <= lastClaimedDay;
                                                                const expectedDay = (lastClaimedDay % 7) + 1;
                                                                const isCurrentUnlockable = item.day ===
                                                                    expectedDay && hasOfferInPast24h && !countdownText;
                                                                return ( <
                                                                    div key = { item.day }
                                                                    onClick = {
                                                                        () => !isClaimed && isCurrentUnlockable &&
                                                                            onClaim(item.day, item.reward) }
                                                                    className = "flex flex-col items-center space-y-2 group cursor-pointer" >
                                                                    <
                                                                    span className = "text-sm font-semibold text-neutral-400" >
                                                                    Day { item.day } < /span> <
                                                                    div className = { `w-16 h-16 rounded-full flex items-center justify-center border transition-all ${isClaimed ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400' : isCurrentUnlockable ? 'bg-brand-orange/20 border-brand-orange text-brand-orangeLight animate-pulse scale-105 shadow-[0_0_15px_rgba(255,122,0,0.4)]' : 'bg-neutral-900 border-white/5 text-neutral-500'}` } >
                                                                    <
                                                                    span className = "material-symbols-rounded font-bold text-xl" >
                                                                    { isClaimed ? 'check_circle' : 'lock' } <
                                                                    /span> <
                                                                    /div> <
                                                                    span className = "text-xs font-bold tracking-wider font-mono text-neutral-300" >
                                                                    ₹ { item.reward.toFixed(1) } < /span> <
                                                                    /div>
                                                                );
                                                            })
                                                        } <
                                                        /div> <
                                                        div className = "pt-2 text-center max-w-xs bg-neutral-900/40 p-3 rounded-xl border border-white/5" >
                                                        <
                                                        p className = "text-red-400 text-xs font-bold leading-relaxed" >
                                                        ⚠️ Complete at least one offer within the last 24 hours to unlock
                                                        today's claim slot. < /p> <
                                                        /div> <
                                                        /div>
                                                    );
                                                }

