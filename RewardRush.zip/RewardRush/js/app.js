/* ============================================================
   FILE: js/app.js
   Main React app: logo, bottom tab item, RewardRushApp (all
   state + screen routing + AUTH screen + Dashboard shell),
   and the ReactDOM mount call.
   ============================================================ */

        /* ─── LOGO COMPONENT ─── */
        function CustomAppLogo({ logoUrl, appName }) {
            if (logoUrl) {
                return <img src={logoUrl} alt={appName} className="w-24 h-24 mx-auto rounded-2xl object-cover" />;
            }
            return ( <
                div className = "w-24 h-24 mx-auto relative flex items-center justify-center select-none" >
                <
                svg viewBox = "0 0 100 100"
                className = "w-full h-full drop-shadow-[0_4px_12px_rgba(255,122,0,0.25)]" >
                <
                defs >
                <
                linearGradient id = "hexGrad"
                x1 = "0%"
                y1 = "0%"
                x2 = "100%"
                y2 = "100%" >
                <
                stop offset = "0%"
                stopColor = "#FFB000" / >
                <
                stop offset = "50%"
                stopColor = "#FF7A00" / >
                <
                stop offset = "100%"
                stopColor = "#D45D00" / >
                <
                /linearGradient> <
                /defs> <
                polygon points = "50,5 90,28 90,72 50,95 10,72 10,28"
                fill = "url(#hexGrad)" / >
                <
                polygon points = "50,11 84,31 84,69 50,89 16,69 16,31"
                fill = "#FFFFFF"
                opacity = "0.15" / >
                <
                path d = "M42,34 C42,28 47,26 50,32 C53,26 58,28 58,34 Z"
                fill = "none"
                stroke = "#221200"
                strokeWidth = "4.5"
                strokeLinecap = "round"
                strokeLinejoin = "round" / >
                <
                path d = "M50,32 L50,42"
                stroke = "#221200"
                strokeWidth = "4.5" / >
                <
                rect x = "36"
                y = "42"
                width = "28"
                height = "24"
                rx = "3"
                fill = "#2E1C0C"
                stroke = "#221200"
                strokeWidth = "4" / >
                <
                rect x = "36"
                y = "49"
                width = "28"
                height = "5"
                fill = "#FF9E2C" / >
                <
                text x = "50"
                y = "60"
                fontFamily = "sans-serif"
                fontWeight = "900"
                fontSize = "13"
                fill = "#FFFFFF"
                textAnchor = "middle" > ₹ < /text> <
                /svg> <
                /div>
            );
        }

        /* ─── BOTTOM TAB ITEM ─── */
        function BottomTabItem({ icon, label, active, onClick }) {
            return ( <
                button onClick = { onClick }
                className = "flex flex-col items-center space-y-1 py-1 px-2 w-16 focus:outline-none" >
                <
                span className = { `material-symbols-rounded transition-colors text-2xl ${active ? 'text-brand-orange font-bold' : 'text-neutral-400'}` } >
                { icon } <
                /span> <
                span className = { `text-[10px] font-medium tracking-wide ${active ? 'text-white font-bold' : 'text-neutral-500'}` } >
                { label } <
                /span> <
                /button>
            );
        }

        /* ─── MAIN APP ─── */
        function RewardRushApp() {
            const [currentScreen, setCurrentScreen] = useState('AUTH');
            const [isRegisterMode, setIsRegisterMode] = useState(false);
            const [activeTab, setActiveTab] = useState('TASKS');
            const [profileSubView, setProfileSubView] = useState(null);
            const [showWithdrawModal, setShowWithdrawModal] = useState(false);
            const [showTermsModal, setShowTermsModal] = useState(false);
            const [showShareModal, setShowShareModal] = useState(false);
            const [showNotificationDropdown, setShowNotificationDropdown] = useState(false);
            const [hasUnreadNotifications, setHasUnreadNotifications] = useState(true);
            const [animationState, setAnimationState] = useState(null);
            const [selectedAmount, setSelectedAmount] = useState(null);
            const [withdrawalMethod, setWithdrawalMethod] = useState('UPI');
            const [walletBalance, setWalletBalance] = useState(0);
            const [transactions, setTransactions] = useState([]);
            const [authEmail, setAuthEmail] = useState('');
            const [authPassword, setAuthPassword] = useState('');
            const [referralCodeInput, setReferralCodeInput] = useState('');
            const [personalDetails, setPersonalDetails] = useState({ fullName: '', email: '', phone: '', avatarUrl: '' });
            const [addressDetails, setAddressDetails] = useState({ line: '', state: '' });
            const [payoutAccounts, setPayoutAccounts] = useState({ upiId: '', redeemEmail: '' });
            const [referralCode, setReferralCode] = useState('');
            const [referralsCount, setReferralsCount] = useState(0);
            const [referralEarnings, setReferralEarnings] = useState(0);
            const [offers, setOffers] = useState([]);
            const [spinsRemaining, setSpinsRemaining] = useState(0);
            const [wheelResult, setWheelResult] = useState(null);
            const [isSpinning, setIsSpinning] = useState(false);
            const [offersCompletedCount, setOffersCompletedCount] = useState(0);
            const [lastClaimedDay, setLastClaimedDay] = useState(0);
            const [lastClaimTimestamp, setLastClaimTimestamp] = useState(0);
            const [lastOfferTimestamp, setLastOfferTimestamp] = useState(0);
            const [userId, setUserId] = useState(null);
            const [branding, setBranding] = useState({ appName: 'Reward Rush', primaryColor: '#0f172a', accentColor: '#fbbf24',
                logoUrl: '', supportEmail: '' });
            const [notifications, setNotifications] = useState([]);
            const wheelRef = useRef(null);

            /* ─── FIREBASE INIT ─── */
            useEffect(() => {
                let mounted = true;
                const initFirebase = async () => {
                    try {
                        const { initializeApp } = await import(
                            "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js");
                        const { getAuth, onAuthStateChanged } = await import(
                            "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js");
                        const { getDatabase, ref, get, update, set, push, onValue } = await import(
                            "https://www.gstatic.com/firebasejs/10.8.0/firebase-database.js");
                        const app = initializeApp(firebaseConfig);
                        authInstance = getAuth(app);
                        dbInstance = getDatabase(app);

                        if (!mounted) return;

                        onValue(ref(dbInstance, 'branding'), (snap) => {
                            const data = snap.val() || {};
                            if (mounted) setBranding(data);
                        });

                        onValue(ref(dbInstance, 'notifications'), (snap) => {
                            if (mounted) setNotifications(normalizeNotifications(snap.val()));
                        });

                        onAuthStateChanged(authInstance, async (user) => {
                            if (!mounted) return;
                            if (user) {
                                setUserId(user.uid);
                                const userRef = ref(dbInstance, 'users/' + user.uid);
                                const snapshot = await get(userRef);
                                if (snapshot.exists()) {
                                    const dbData = snapshot.val();
                                    if (dbData.personalDetails) setPersonalDetails(dbData.personalDetails);
                                    if (dbData.addressDetails) setAddressDetails(dbData.addressDetails);
                                    if (dbData.payoutDetails) setPayoutAccounts(dbData.payoutDetails);
                                    if (dbData.balance !== undefined) setWalletBalance(dbData.balance);
                                    if (dbData.referralCode) setReferralCode(dbData.referralCode);
                                    if (dbData.referrals) setReferralsCount(dbData.referrals.length || 0);
                                    if (dbData.referralEarnings) setReferralEarnings(dbData.referralEarnings);
                                    if (dbData.spinsRemaining !== undefined) setSpinsRemaining(dbData.spinsRemaining);
                                    if (dbData.offersCompleted !== undefined) setOffersCompletedCount(dbData
                                    .offersCompleted);
                                    if (dbData.lastClaimedDay !== undefined) setLastClaimedDay(dbData.lastClaimedDay);
                                    if (dbData.lastClaimTimestamp !== undefined) setLastClaimTimestamp(dbData
                                        .lastClaimTimestamp);
                                    if (dbData.lastOfferTimestamp !== undefined) setLastOfferTimestamp(dbData
                                        .lastOfferTimestamp);
                                    loadOffers();
                                    loadTransactions(user.uid);
                                } else {
                                    const newCode = generateReferralCode();
                                    const newUserData = {
                                        personalDetails: { fullName: user.displayName || personalDetails.fullName ||
                                                'Member Node', email: user.email || authEmail, phone: '',
                                            avatarUrl: user.photoURL || '' },
                                        addressDetails: { line: '', state: '' },
                                        payoutDetails: { upiId: '', redeemEmail: '' },
                                        balance: 0,
                                        referralCode: newCode,
                                        referredBy: '',
                                        referrals: [],
                                        referralEarnings: 0,
                                        spinsRemaining: 0,
                                        offersCompleted: 0,
                                        lastClaimedDay: 0,
                                        lastClaimTimestamp: 0,
                                        lastOfferTimestamp: 0,
                                        createdAt: Date.now()
                                    };
                                    let referrerUid = null;
                                    if (referralCodeInput) {
                                        const usersSnap = await get(ref(dbInstance, 'users'));
                                        const users = usersSnap.val();
                                        if (users) {
                                            for (let uid in users) {
                                                if (users[uid].referralCode === referralCodeInput.toUpperCase()) {
                                                    referrerUid = uid;
                                                    break;
                                                }
                                            }
                                        }
                                        if (referrerUid) {
                                            const referrerRef = ref(dbInstance, 'users/' + referrerUid);
                                            const referrerSnap = await get(referrerRef);
                                            const referrerData = referrerSnap.val();
                                            if (referrerData) {
                                                const newBalance = (referrerData.balance || 0) + 1;
                                                const newEarnings = (referrerData.referralEarnings || 0) + 1;
                                                const referrals = referrerData.referrals || [];
                                                referrals.push(user.uid);
                                                await update(referrerRef, {
                                                    balance: newBalance,
                                                    referralEarnings: newEarnings,
                                                    referrals: referrals
                                                });
                                                const txRef = push(ref(dbInstance, 'transactions'));
                                                await set(txRef, {
                                                    uid: referrerUid,
                                                    amount: 1,
                                                    type: 'REFERRAL',
                                                    description: `Referral bonus for ${user.email}`,
                                                    timestamp: Date.now(),
                                                    status: 'SUCCESS'
                                                });
                                            }
                                            newUserData.referredBy = referrerUid;
                                        }
                                    }
                                    await set(ref(dbInstance, 'users/' + user.uid), newUserData);
                                    setWalletBalance(0);
                                    setReferralCode(newCode);
                                    setReferralsCount(0);
                                    setReferralEarnings(0);
                                    setSpinsRemaining(0);
                                    setOffersCompletedCount(0);
                                    setLastClaimedDay(0);
                                    setLastClaimTimestamp(0);
                                    setLastOfferTimestamp(0);
                                    setPersonalDetails(newUserData.personalDetails);
                                    setAddressDetails(newUserData.addressDetails);
                                    setPayoutAccounts(newUserData.payoutDetails);
                                    loadOffers();
                                    loadTransactions(user.uid);
                                }
                                setCurrentScreen('DASHBOARD');
                            } else {
                                setCurrentScreen('AUTH');
                                setUserId(null);
                            }
                        });
                    } catch (err) {
                        console.error('Firebase init error:', err);
                    }
                };
                initFirebase();
                return () => { mounted = false; };
            }, []);

            /* ─── LOAD OFFERS ─── */
            const loadOffers = useCallback(async () => {
                try {
                    const { ref, get, push, set } = await import(
                        "https://www.gstatic.com/firebasejs/10.8.0/firebase-database.js");
                    const offersSnap = await get(ref(dbInstance, 'offers'));
                    if (offersSnap.exists()) {
                        const offersData = offersSnap.val();
                        const offersList = Object.keys(offersData).map(key => ({ id: key, ...offersData[key] }));
                        setOffers(offersList);
                    } else {
                        const defaultOffers = [];
                        for (let i = 1; i <= 25; i++) {
                            defaultOffers.push({
                                title: `Watch Ad #${i}`,
                                description: `Earn 1 spin by watching this ad`,
                                rewardSpins: 1
                            });
                        }
                        for (let offer of defaultOffers) {
                            const newRef = push(ref(dbInstance, 'offers'));
                            await set(newRef, offer);
                        }
                        loadOffers();
                    }
                } catch (e) { console.error(e); }
            }, []);

            /* ─── LOAD TRANSACTIONS ─── */
            const loadTransactions = useCallback(async (uid) => {
                try {
                    const { ref, get } = await import(
                        "https://www.gstatic.com/firebasejs/10.8.0/firebase-database.js");
                    const txRef = ref(dbInstance, 'transactions');
                    const txSnap = await get(txRef);
                    if (txSnap.exists()) {
                        const allTx = txSnap.val();
                        const userTx = Object.keys(allTx)
                            .filter(key => allTx[key].uid === uid)
                            .map(key => ({ id: key, ...allTx[key] }));
                        userTx.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
                        setTransactions(userTx);
                    } else {
                        setTransactions([]);
                    }
                } catch (e) { console.error(e); }
            }, []);

            /* ─── AUTH HANDLERS (see js/auth.js) ─── */
            const handleAuthAction = async (e) => {
                e.preventDefault();
                if (!authEmail || !authPassword) return;
                try {
                    await authEmailPasswordAction(isRegisterMode, authEmail, authPassword);
                    setAnimationState('LOGIN_SUCCESS');
                    setTimeout(() => setAnimationState(null), 1500);
                } catch (error) {
                    alert(error.message);
                }
            };

            const handleGoogleSignIn = async () => {
                try {
                    await authGoogleSignIn();
                    setAnimationState('LOGIN_SUCCESS');
                    setTimeout(() => setAnimationState(null), 1500);
                } catch (error) {
                    alert("Google Sign-In Failed: " + error.message);
                }
            };

            const logoutUser = async () => {
                await authLogout();
                setCurrentScreen('AUTH');
                setProfileSubView(null);
                setShowNotificationDropdown(false);
            };

            const navigateToProfileSub = (view) => {
                setProfileSubView(view);
                setActiveTab('PROFILE');
            };

            /* ─── WITHDRAWAL (see js/withdraw.js) ─── */
            const verifyAndOpenWithdrawal = () => {
                if (!isPayoutDetailsComplete(personalDetails, payoutAccounts)) {
                    alert("Please complete your payment details before withdrawing.");
                    navigateToProfileSub('PAYOUT');
                    return;
                }
                setShowWithdrawModal(true);
            };

            const triggerWithdrawal = async () => {
                if (!selectedAmount) return;
                const amtNumber = parseFloat(selectedAmount);
                if (walletBalance < amtNumber) { alert("Insufficient balance!"); return; }
                if (!isPayoutDetailsComplete(personalDetails, payoutAccounts)) {
                    alert("Please complete your payment details before withdrawing.");
                    setShowWithdrawModal(false);
                    navigateToProfileSub('PAYOUT');
                    return;
                }
                setShowWithdrawModal(false);
                setAnimationState('PROCESSING');
                try {
                    const result = await submitWithdrawalRequest({
                        amount: amtNumber,
                        method: withdrawalMethod,
                        personalDetails,
                        payoutAccounts
                    });
                    if (!result.success) {
                        alert("Withdrawal error: " + result.error);
                        setAnimationState(null);
                        return;
                    }
                    setWalletBalance(result.newBalance);
                    const user = authInstance.currentUser;
                    if (user) loadTransactions(user.uid);
                    setAnimationState('SUCCESS');
                    setTimeout(() => setAnimationState(null), 2000);
                } catch (err) { alert("Withdrawal error: " + err.message);
                    setAnimationState(null); }
            };

            /* ─── OFFERS & SPINS ─── */
            const completeOffer = async (offerId) => {
                try {
                    const { ref, update, get, push, set } = await import(
                        "https://www.gstatic.com/firebasejs/10.8.0/firebase-database.js");
                    const user = authInstance.currentUser;
                    if (!user) return;
                    const userRef = ref(dbInstance, 'users/' + user.uid);
                    const snap = await get(userRef);
                    const data = snap.val();
                    const now = Date.now();
                    const newSpins = (data.spinsRemaining || 0) + 1;
                    const newOffersCompleted = (data.offersCompleted || 0) + 1;
                    await update(userRef, {
                        spinsRemaining: newSpins,
                        offersCompleted: newOffersCompleted,
                        lastOfferTimestamp: now
                    });
                    setSpinsRemaining(newSpins);
                    setOffersCompletedCount(newOffersCompleted);
                    setLastOfferTimestamp(now);
                    const txRef = push(ref(dbInstance, 'transactions'));
                    await set(txRef, {
                        uid: user.uid,
                        amount: 0,
                        type: 'OFFER_COMPLETE',
                        description: `Completed offer: ${offerId}`,
                        timestamp: now,
                        status: 'SUCCESS'
                    });
                    loadTransactions(user.uid);
                    alert("Offer completed! You earned 1 spin.");
                } catch (err) { alert("Error completing offer: " + err.message); }
            };

            /* ─── SPIN WHEEL ─── */
            const spinWheel = () => {
                if (isSpinning) return;
                if (spinsRemaining <= 0) {
                    alert("No spins left. Complete an offer.");
                    return;
                }
                setIsSpinning(true);
                setWheelResult(null);

                const securePrizes = [1, 2, 3];
                const result = securePrizes[Math.floor(Math.random() * securePrizes.length)];
                const targetIndex = result - 1;
                const segmentAngle = 36;
                const targetDegrees = 360 - (targetIndex * segmentAngle + (segmentAngle / 2));
                const extraTurns = 5 + Math.floor(Math.random() * 3);
                const totalRotation = (extraTurns * 360) + targetDegrees;

                const wheel = wheelRef.current;
                if (wheel) {
                    wheel.style.transition = 'none';
                    wheel.style.transform = 'rotate(0deg)';
                    void wheel.offsetHeight;
                    wheel.style.transition = 'transform 4s cubic-bezier(0.15, 0.75, 0.2, 1)';
                    wheel.style.transform = `rotate(${totalRotation}deg)`;
                }

                setTimeout(() => {
                    setWheelResult(result);
                    creditSpinResult(result);
                    setIsSpinning(false);
                    setSpinsRemaining(prev => Math.max(0, prev - 1));
                    updateSpinsRemaining(-1);
                }, 4400);
            };

            const creditSpinResult = async (amount) => {
                try {
                    const { ref, update, push, set } = await import(
                        "https://www.gstatic.com/firebasejs/10.8.0/firebase-database.js");
                    const user = authInstance.currentUser;
                    if (!user) return;
                    const userRef = ref(dbInstance, 'users/' + user.uid);
                    const newBalance = (walletBalance || 0) + amount;
                    await update(userRef, { balance: newBalance });
                    setWalletBalance(newBalance);
                    const txRef = push(ref(dbInstance, 'transactions'));
                    await set(txRef, {
                        uid: user.uid,
                        amount: amount,
                        type: 'SPIN_REWARD',
                        description: `Spin wheel reward - ${amount}`,
                        timestamp: Date.now(),
                        status: 'SUCCESS'
                    });
                    loadTransactions(user.uid);
                } catch (err) { alert("Error crediting spin reward: " + err.message); }
            };

            const updateSpinsRemaining = async (delta) => {
                try {
                    const { ref, update, get } = await import(
                        "https://www.gstatic.com/firebasejs/10.8.0/firebase-database.js");
                    const user = authInstance.currentUser;
                    if (!user) return;
                    const userRef = ref(dbInstance, 'users/' + user.uid);
                    const snap = await get(userRef);
                    const data = snap.val();
                    const newSpins = Math.max(0, (data.spinsRemaining || 0) + delta);
                    await update(userRef, { spinsRemaining: newSpins });
                } catch (err) { console.error(err); }
            };

            /* ─── DAILY CHECK-IN ─── */
            const handleClaimDailyReward = async (dayNum, rewardAmt) => {
                const now = Date.now();
                const dynamicWindowLimit = 24 * 60 * 60 * 1000;
                if (now - lastOfferTimestamp > dynamicWindowLimit || offersCompletedCount <= 0) {
                    alert("Complete at least one offer within the last 24 hours to unlock today's reward.");
                    return;
                }
                if (lastClaimTimestamp > 0 && (now - lastClaimTimestamp < dynamicWindowLimit)) {
                    const remaining = dynamicWindowLimit - (now - lastClaimTimestamp);
                    const hours = Math.floor(remaining / (3600 * 1000));
                    const minutes = Math.floor((remaining % (3600 * 1000)) / (60 * 1000));
                    alert(`Next claim available in ${hours}h ${minutes}m.`);
                    return;
                }
                const expectedDay = (lastClaimedDay % 7) + 1;
                if (dayNum !== expectedDay) {
                    alert(`Please claim Day ${expectedDay} sequentially!`);
                    return;
                }
                try {
                    const { ref, update, push, set } = await import(
                        "https://www.gstatic.com/firebasejs/10.8.0/firebase-database.js");
                    const user = authInstance.currentUser;
                    if (!user) return;
                    const userRef = ref(dbInstance, 'users/' + user.uid);
                    const newBalance = walletBalance + rewardAmt;
                    await update(userRef, {
                        balance: newBalance,
                        lastClaimedDay: dayNum,
                        lastClaimTimestamp: now
                    });
                    setWalletBalance(newBalance);
                    setLastClaimedDay(dayNum);
                    setLastClaimTimestamp(now);
                    const txRef = push(ref(dbInstance, 'transactions'));
                    await set(txRef, {
                        uid: user.uid,
                        amount: rewardAmt,
                        type: 'DAILY_CHECKIN',
                        description: `Daily Check-In Reward Day ${dayNum}`,
                        timestamp: now,
                        status: 'SUCCESS'
                    });
                    loadTransactions(user.uid);
                    alert(`Successfully claimed ₹${rewardAmt} for Day ${dayNum}!`);
                } catch (err) { alert("Error claiming reward: " + err.message); }
            };

            /* ─── SAVE PROFILE ─── */
            const saveProfileDataNode = async (type, updatedPayload) => {
                try {
                    const { ref, update } = await import(
                        "https://www.gstatic.com/firebasejs/10.8.0/firebase-database.js");
                    const user = authInstance.currentUser;
                    if (!user) return;
                    const updatePath = {};
                    if (type === 'PERSONAL') {
                        setPersonalDetails({ ...personalDetails, fullName: updatedPayload.fullName, phone: updatedPayload
                                .phone, avatarUrl: updatedPayload.avatarUrl });
                        updatePath['personalDetails'] = { ...personalDetails, fullName: updatedPayload.fullName,
                            phone: updatedPayload.phone, avatarUrl: updatedPayload.avatarUrl };
                    }
                    if (type === 'ADDRESS') {
                        setAddressDetails(updatedPayload);
                        updatePath['addressDetails'] = updatedPayload;
                    }
                    if (type === 'PAYOUT') {
                        setPayoutAccounts(updatedPayload.payout);
                        setPersonalDetails({ ...personalDetails, fullName: updatedPayload.fullName, phone: updatedPayload
                                .phone });
                        updatePath['payoutDetails'] = updatedPayload.payout;
                        updatePath['personalDetails'] = { ...personalDetails, fullName: updatedPayload.fullName,
                            phone: updatedPayload.phone };
                    }
                    await update(ref(dbInstance, 'users/' + user.uid), updatePath);
                    setAnimationState('SAVE_SUCCESS');
                    setTimeout(() => { setAnimationState(null);
                        setProfileSubView(null); }, 1200);
                } catch (err) { alert("Sync Error: " + err.message); }
            };

            /* ─── SHARE ─── */
            const openShareModal = () => setShowShareModal(true);
            const closeShareModal = () => setShowShareModal(false);

            const shareOnPlatform = (platform) => {
                const message =
                    `Join Reward Rush using my referral code: ${referralCode} and get ₹1 bonus! Download the app now.`;
                const encoded = encodeURIComponent(message);
                let url = '';
                switch (platform) {
                    case 'whatsapp':
                        url = `https://wa.me/?text=${encoded}`;
                        break;
                    case 'telegram':
                        url = `https://t.me/share/url?url=${encodeURIComponent('https://rewardrush.com')}&text=${encoded}`;
                        break;
                    case 'gmail':
                        url = `mailto:?subject=${encodeURIComponent('Join Reward Rush')}&body=${encoded}`;
                        break;
                    case 'facebook':
                        url = `https://www.facebook.com/sharer/sharer.php?quote=${encoded}`;
                        break;
                    case 'twitter':
                        url = `https://twitter.com/intent/tweet?text=${encoded}`;
                        break;
                    case 'copy':
                        navigator.clipboard.writeText(message).then(() => { alert('Copied!'); }).catch(() => { alert(
                                'Copy: ' + message); });
                        closeShareModal();
                        return;
                    default:
                        return;
                }
                if (url) { window.open(url, '_blank');
                    closeShareModal(); }
            };

            /* ─── RENDER: AUTH SCREEN ─── */
            if (currentScreen === 'AUTH' && animationState !== 'LOGIN_SUCCESS') {
                return ( <
                    div className = "mx-auto max-w-md min-h-screen bg-brand-black flex flex-col justify-between px-6 py-8 border-x border-neutral-900 relative select-none" >
                    <
                    div className = "my-auto space-y-6 w-full" >
                    <
                    div className = "text-center space-y-2" >
                    <
                    CustomAppLogo logoUrl = { branding.logoUrl }
                    appName = { branding.appName }
                    /> <
                    h2 className = "text-2xl font-black tracking-tight text-white mt-3" > { branding.appName || 'Reward Rush' } <
                    /h2> <
                    p className = "text-xs text-brand-grayMuted" > Premium serverless extraction dashboard configuration < /p> <
                    /div> <
                    div className = "marquee" > < span > ⚡ New user ? Create your account now! ⚡ Earn ₹1 for each referral! ⚡ < /span></div >
                    <
                    div className = "flex items-center space-x-2 justify-center py-2.5 px-3 bg-gradient-to-r from-orange-500/10 via-amber-400/10 to-orange-500/10 rounded-xl border border-orange-500/20" >
                    <
                    div className = "h-[1px] bg-gradient-to-r from-transparent via-brand-orange to-amber-400 flex-1" > < /div> <
                    span className = "text-[10px] font-black tracking-wider text-brand-orangeLight uppercase animate-pulse flex items-center space-x-1" >
                    <
                    span className = "material-symbols-rounded text-[13px] text-amber-400" > gpp_maybe < /span> <
                    span > First create account or choose Google < /span> <
                    /span> <
                    div className = "h-[1px] bg-gradient-to-l from-transparent via-brand-orange to-amber-400 flex-1" > < /div> <
                    /div> <
                    form onSubmit = { handleAuthAction }
                    className = "space-y-4" >
                    {
                        isRegisterMode && ( <
                            >
                            <
                            div className = "bg-neutral-900/60 p-4 rounded-xl border border-white/5 space-y-1" >
                            <
                            label className = "text-[10px] text-brand-grayMuted uppercase font-bold tracking-wider" > Full
                            Name < /label> <
                            input type = "text"
                            required className = "w-full bg-transparent text-sm font-medium text-white outline-none"
                            value = { personalDetails.fullName }
                            onChange = { (e) => setPersonalDetails({ ...personalDetails, fullName: e.target.value }) }
                            placeholder = "Enter official name" / >
                            <
                            /div> <
                            div className = "bg-neutral-900/60 p-4 rounded-xl border border-white/5 space-y-1" >
                            <
                            label className = "text-[10px] text-brand-grayMuted uppercase font-bold tracking-wider" >
                            Referral Code(optional) < /label> <
                            input type = "text"
                            className = "w-full bg-transparent text-sm font-medium text-white outline-none"
                            value = { referralCodeInput }
                            onChange = { (e) => setReferralCodeInput(e.target.value.toUpperCase()) }
                            placeholder = "Enter referrer's code" / >
                            <
                            p className = "text-[9px] text-brand-grayMuted mt-1" > Leave blank to create account without
                            referral. < /p> <
                            /div> <
                            />
                        )
                    } <
                    div className = "bg-neutral-900/60 p-4 rounded-xl border border-white/5 space-y-1" >
                    <
                    label className = "text-[10px] text-brand-grayMuted uppercase font-bold tracking-wider" > Gmail Address <
                    /label> <
                    input type = "email"
                    required className = "w-full bg-transparent text-sm font-medium text-white outline-none"
                    value = { authEmail }
                    onChange = { (e) => setAuthEmail(e.target.value) }
                    placeholder = "Enter your email address" / >
                    <
                    /div> <
                    div className = "bg-neutral-900/60 p-4 rounded-xl border border-white/5 space-y-1" >
                    <
                    label className = "text-[10px] text-brand-grayMuted uppercase font-bold tracking-wider" > Security
                    Access Password < /label> <
                    input type = "password"
                    required className = "w-full bg-transparent text-sm font-medium text-white outline-none"
                    value = { authPassword }
                    onChange = { (e) => setAuthPassword(e.target.value) }
                    placeholder = { isRegisterMode ? "Create a password" : "Enter your security password" }
                    /> <
                    /div> <
                    button type = "submit"
                    className = "w-full py-4 rounded-xl orange-gradient text-white text-sm font-bold shadow-md tracking-wide mt-2 transform active:scale-98 transition"
                    style = { { background: `linear-gradient(135deg, ${branding.accentColor || '#FFA733'}, ${branding.primaryColor || '#FF7A00'})` } } >
                    {
                        isRegisterMode ? 'Register & Setup Node' : 'Direct Account Access' } <
                    /button> <
                    /form>

                    <
                    div className = "relative flex py-2 items-center" >
                    <
                    div className = "flex-grow border-t border-white/10" > < /div> <
                    span className = "flex-shrink mx-4 text-neutral-500 font-bold text-[10px] tracking-widest uppercase" >
                    OR < /span> <
                    div className = "flex-grow border-t border-white/10" > < /div> <
                    /div>

                    <
                    button onClick = { handleGoogleSignIn }
                    type = "button"
                    className = "w-full py-3.5 rounded-xl bg-white text-black text-xs font-bold shadow-sm tracking-wide flex items-center justify-center space-x-2 transform active:scale-98 transition hover:bg-neutral-100" >
                    <
                    svg className = "w-4 h-4"
                    viewBox = "0 0 24 24" >
                    <
                    path d = "M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    fill = "#4285F4" / >
                    <
                    path d = "M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    fill = "#34A853" / >
                    <
                    path d = "M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.85z"
                    fill = "#FBBC05" / >
                    <
                    path d = "M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                    fill = "#EA4335" / >
                    <
                    /svg> <
                    span > Continue with Google < /span> <
                    /button>

                    <
                    div className = "text-center" >
                    <
                    button type = "button"
                    onClick = { () => setIsRegisterMode(!isRegisterMode) }
                    className = "text-xs font-semibold text-brand-orangeLight hover:underline"
                    style = { { color: branding.accentColor } } >
                    {
                        isRegisterMode ? 'Already registered? Direct Access here' :
                        'New allocation? Register user node entry' } <
                    /button> <
                    /div> <
                    /div> <
                    div className = "w-full pt-4 flex flex-col items-center space-y-1.5" >
                    <
                    div className = "w-2/3 h-[3px] rounded-full orange-gradient glow-line"
                    style = { { background: `linear-gradient(135deg, ${branding.primaryColor}, ${branding.accentColor})` } } >
                    < /div> <
                    span className = "text-[8px] font-mono tracking-widest text-brand-grayMuted uppercase" > Secure
                    Authorization Cluster < /span> <
                    /div> <
                    /div>
                );
            }

            /* ─── RENDER: DASHBOARD ─── */
            return ( <
                div className = "mx-auto max-w-md min-h-screen bg-brand-black flex flex-col relative border-x border-neutral-900 pb-24" >
                {
                    profileSubView === null && animationState === null && ( <
                        div className = "flex justify-between items-center px-4 py-4 bg-brand-black sticky top-0 z-40" >
                        <
                        div className = "flex items-center space-x-2" >
                        <
                        button onClick = { () => setActiveTab('CAMPAIGNS') }
                        className = { `p-1 bg-neutral-900 rounded-full border border-white/5 flex items-center justify-center transition ${activeTab === 'CAMPAIGNS' ? 'text-brand-orange' : 'text-neutral-400'}` } >
                        <
                        span className = "material-symbols-rounded text-xl" > calendar_month < /span> <
                        /button> <
                        h1 className = "text-2xl font-bold tracking-tight text-white"
                        style = { { color: branding.primaryColor } } >
                        {
                            activeTab === 'CAMPAIGNS' && 'Daily Rewards' }
                        {
                            activeTab === 'TASKS' && 'Tasks' }
                        {
                            activeTab === 'OFFERS' && 'Offers & Spin' }
                        {
                            activeTab === 'TRANSACTIONS' && 'History Log' }
                        {
                            activeTab === 'SUPPORT' && 'AI Support Desk' }
                        {
                            activeTab === 'PROFILE' && 'Profile' }
                        {
                            activeTab === 'SARVES' && 'Surveys' } <
                        /h1> <
                        /div> <
                        div className = "flex items-center space-x-2 relative" >
                        <
                        button onClick = { () => setActiveTab('SUPPORT') }
                        className = "flex items-center space-x-1 px-3 py-1.5 rounded-full bg-neutral-900 border border-white/5 text-xs text-neutral-300 font-medium" >
                        <
                        span className = "material-symbols-rounded text-sm"
                        style = { { color: branding.accentColor } } > smart_toy < /span> <
                        span > AI Desk < /span> <
                        /button>

                        <
                        div className = "relative inline-block text-left"
                        onClick = { (e) => e.stopPropagation() } >
                        <
                        button onClick = {
                            () => {
                                setShowNotificationDropdown(!showNotificationDropdown);
                                setHasUnreadNotifications(false);
                            } }
                        className = "relative p-2 bg-neutral-900 hover:bg-neutral-800 border border-white/5 text-neutral-300 rounded-full transition focus:outline-none flex items-center justify-center" >
                        <
                        span className = "material-symbols-rounded text-xl" > notifications < /span> {
                            hasUnreadNotifications && notifications.length > 0 && ( <
                                span className = "absolute top-1 right-1 flex h-2 w-2" >
                                <
                                span className = "animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" >
                                < /span> <
                                span className = "relative inline-flex rounded-full h-2 w-2 bg-red-500" > < /span> <
                                /span>
                            )
                        } <
                        /button> {
                            showNotificationDropdown && ( <
                                div className = "absolute right-0 mt-3 w-72 bg-neutral-950 border border-white/10 rounded-2xl shadow-2xl z-50 overflow-hidden" >
                                <
                                div className = "p-3 border-b border-white/10 flex justify-between items-center bg-neutral-900/50" >
                                <
                                h3 className = "font-bold text-xs text-white" > Notifications Log < /h3> <
                                button onClick = {
                                    (e) => {
                                        e.stopPropagation();
                                        setNotifications([]);
                                    } }
                                className = "text-[10px] text-neutral-500 hover:text-red-400 font-bold transition" >
                                Clear All < /button> <
                                /div> <
                                div className = "max-h-64 overflow-y-auto p-2 space-y-2 bg-black/40 no-scrollbar" >
                                {
                                    notifications.length === 0 ? ( <
                                        div className = "p-6 text-center text-neutral-600 text-[11px] font-medium" >
                                        No active notifications available. < /div>
                                    ) : (
                                        notifications.map(n => ( <
                                            div key = { n.id }
                                            className = "p-3 bg-neutral-900 rounded-xl border border-white/5 space-y-1" >
                                            <
                                            div className = "flex justify-between items-start" >
                                            <
                                            h4 className = "font-bold text-white text-[11px] truncate max-w-[150px]" >
                                            { n.title } < /h4> <
                                            span className = { `text-[8px] font-black uppercase px-1.5 py-0.5 rounded ${n.type === 'alert' ? 'bg-red-950 text-red-400' : n.type === 'warning' ? 'bg-amber-950 text-amber-400' : n.type === 'success' ? 'bg-emerald-950 text-emerald-400' : 'bg-blue-950 text-blue-400'}` } >
                                            { n.type } < /span> <
                                            /div> <
                                            p className = "text-[10px] text-neutral-400 line-clamp-2 leading-relaxed" >
                                            { n.message } < /p> <
                                            span className = "text-[8px] text-neutral-600 block pt-1 font-mono" >
                                            { new Date(n.createdAt).toLocaleString() } < /span> <
                                            /div>
                                        ))
                                    )
                                } <
                                /div> <
                                /div>
                            )
                        } <
                        /div> <
                        /div> <
                        /div>
                    )
                }

                <
                div className = "flex-1 px-4 overflow-y-auto no-scrollbar" >
                {
                    animationState !== null ? ( <
                        div className = "flex flex-col items-center justify-center min-h-[70vh] px-6 text-center space-y-8" >
                        <
                        div className = "relative w-32 h-32 flex items-center justify-center" > {
                            animationState === 'PROCESSING' ? ( <
                                >
                                <
                                div className = "absolute inset-0 rounded-full border-4 border-t-brand-orange border-r-transparent border-b-transparent border-l-white/10 animate-circle-spin" >
                                < /div> <
                                div className = "w-16 h-16 rounded-2xl bg-neutral-900 flex items-center justify-center" >
                                <
                                span className = "material-symbols-rounded text-3xl text-neutral-400" > phone_iphone <
                                /span> <
                                /div> <
                                />
                            ) : ( <
                                >
                                <
                                div className = "absolute inset-0 rounded-full bg-emerald-500/10 scale-110" > < /div> <
                                div className = "w-20 h-20 rounded-full bg-emerald-500 flex items-center justify-center shadow-lg shadow-emerald-500/20" >
                                <
                                span className = "material-symbols-rounded text-4xl text-black font-black" > check <
                                /span> <
                                /div> <
                                />
                            )
                        } <
                        /div> <
                        div className = "space-y-3 max-w-xs" >
                        <
                        h3 className = "text-xl font-black tracking-tight text-white" > {
                            animationState === 'PROCESSING' && 'Processing Transaction...' }
                        {
                            animationState === 'SUCCESS' && 'Success!' }
                        {
                            animationState === 'SAVE_SUCCESS' && 'Saved Successfully' }
                        {
                            animationState === 'LOGIN_SUCCESS' && 'Access Authorized' } <
                        /h3> <
                        p className = "text-xs text-brand-grayMuted leading-relaxed" > {
                            animationState === 'PROCESSING' && 'Securing allocation channels...' }
                        {
                            animationState === 'SUCCESS' &&
                            'You will receive your money in 24 hours or in the 2 days.' }
                        {
                            animationState === 'SAVE_SUCCESS' && 'Your details have been saved successfully!' }
                        {
                            animationState === 'LOGIN_SUCCESS' &&
                            'User session synced dynamically via Realtime cluster synchronization.' } <
                        /p> <
                        /div> {
                            animationState === 'SUCCESS' && ( <
                                button onClick = { () => setAnimationState(null) }
                                className = "px-8 py-3 rounded-xl bg-neutral-900 border border-white/10 text-xs font-bold text-white tracking-wide" >
                                Return to Dashboard < /button>
                            )
                        } <
                        /div>
                    ) : activeTab === 'PROFILE' && profileSubView !== null ? ( <
                        div > {
                            profileSubView === 'PERSONAL' && < PersonalDetailsView data = { personalDetails }
                            onSave = { (updated) => saveProfileDataNode('PERSONAL', updated) }
                            onBack = { () => setProfileSubView(null) }
                            />} {
                                profileSubView === 'ADDRESS' && < AddressDetailsView data = { addressDetails }
                                onSave = { (updated) => saveProfileDataNode('ADDRESS', updated) }
                                onBack = { () => setProfileSubView(null) }
                                />} {
                                    profileSubView === 'PAYOUT' && < PayoutDetailsView data = { { payout: payoutAccounts,
                                            name: personalDetails.fullName, phone: personalDetails.phone,
                                            email: personalDetails.email } }
                                        onSave = { (updated) => saveProfileDataNode('PAYOUT', updated) }
                                        onBack = { () => setProfileSubView(null) }
                                        />} <
                                        /div>
                                    ) : ( <
                                        div className = "h-full" > {
                                            activeTab === 'CAMPAIGNS' && < DailyCheckInView lastClaimedDay = { lastClaimedDay }
                                            lastClaimTimestamp = { lastClaimTimestamp }
                                            offersCompletedCount = { offersCompletedCount }
                                            lastOfferTimestamp = { lastOfferTimestamp }
                                            onClaim = { handleClaimDailyReward }
                                            />} {
                                                activeTab === 'TASKS' && < TasksPlaceholder / >
                                            } {
                                                activeTab === 'OFFERS' && < OffersTab offers = { offers }
                                                onCompleteOffer = { completeOffer }
                                                spinsRemaining = { spinsRemaining }
                                                onSpin = { spinWheel }
                                                isSpinning = { isSpinning }
                                                wheelRef = { wheelRef }
                                                wheelResult = { wheelResult }
                                                accentColor = { branding.accentColor }
                                                />} {
                                                    activeTab === 'TRANSACTIONS' && < TransactionsTab balance = { walletBalance }
                                                    transactionList = { transactions }
                                                    onWithdrawClick = { verifyAndOpenWithdrawal }
                                                    onRefreshClick = {
                                                        () => { if (authInstance.currentUser) loadTransactions(authInstance
                                                                .currentUser.uid); } }
                                                    accentColor = { branding.accentColor }
                                                    />} {
                                                        activeTab === 'SUPPORT' && < SupportTab payoutInfo = { payoutAccounts }
                                                        onOpenTerms = { () => setShowTermsModal(true) }
                                                        accentColor = { branding.accentColor }
                                                        />} {
                                                            activeTab === 'SARVES' && < SarvesTab userId = { userId }
                                                            />} {
                                                                activeTab === 'PROFILE' && < ProfileTab userData = { personalDetails }
                                                                referralCode = { referralCode }
                                                                referralsCount = { referralsCount }
                                                                referralEarnings = { referralEarnings }
                                                                onShare = { openShareModal }
                                                                onNavigate = { navigateToProfileSub }
                                                                onOpenTerms = { () => setShowTermsModal(true) }
                                                                onLogout = { logoutUser }
                                                                accentColor = { branding.accentColor }
                                                                />} <
                                                                /div>
                                                            )
                                                        } <
                                                        /div>

                                                        {
                                                            showShareModal && ( <
                                                                div className = "fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
                                                                onClick = { closeShareModal } >
                                                                <
                                                                div className = "w-full max-w-sm bg-neutral-950 border border-white/10 rounded-2xl p-6"
                                                                onClick = { (e) => e.stopPropagation() } >
                                                                <
                                                                div className = "flex justify-between items-center mb-4" >
                                                                <
                                                                h3 className = "text-lg font-bold text-white" > Share
                                                                Referral < /h3> <
                                                                button onClick = { closeShareModal }
                                                                className = "w-8 h-8 rounded-full bg-neutral-900 flex items-center justify-center text-neutral-400" >
                                                                <
                                                                span className = "material-symbols-rounded text-sm" >
                                                                close < /span> <
                                                                /button> <
                                                                /div> <
                                                                p className = "text-xs text-brand-grayMuted mb-4" > Choose
                                                                a platform to share your referral code < /p> <
                                                                div className = "grid grid-cols-3 gap-3" >
                                                                <
                                                                button className = "share-platform-btn"
                                                                onClick = { () => shareOnPlatform('whatsapp') } >
                                                                <
                                                                span className = "platform-icon" > 💬 < /span> <
                                                                span className = "platform-label" > WhatsApp < /span> <
                                                                /button> <
                                                                button className = "share-platform-btn"
                                                                onClick = { () => shareOnPlatform('telegram') } >
                                                                <
                                                                span className = "platform-icon" > ✈️ < /span> <
                                                                span className = "platform-label" > Telegram < /span> <
                                                                /button> <
                                                                button className = "share-platform-btn"
                                                                onClick = { () => shareOnPlatform('gmail') } >
                                                                <
                                                                span className = "platform-icon" > 📧 < /span> <
                                                                span className = "platform-label" > Gmail < /span> <
                                                                /button> <
                                                                button className = "share-platform-btn"
                                                                onClick = { () => shareOnPlatform('facebook') } >
                                                                <
                                                                span className = "platform-icon" > 📘 < /span> <
                                                                span className = "platform-label" > Facebook < /span> <
                                                                /button> <
                                                                button className = "share-platform-btn"
                                                                onClick = { () => shareOnPlatform('twitter') } >
                                                                <
                                                                span className = "platform-icon" > 🐦 < /span> <
                                                                span className = "platform-label" > Twitter < /span> <
                                                                /button> <
                                                                button className = "share-platform-btn"
                                                                onClick = { () => shareOnPlatform('copy') } >
                                                                <
                                                                span className = "platform-icon" > 📋 < /span> <
                                                                span className = "platform-label" > Copy Link < /span> <
                                                                /button> <
                                                                /div> <
                                                                div className = "mt-4 p-3 bg-neutral-900 rounded-xl border border-white/5" >
                                                                <
                                                                p className = "text-[10px] text-brand-grayMuted font-mono truncate" >
                                                                { referralCode } < /p> <
                                                                /div> <
                                                                /div> <
                                                                /div>
                                                            )
                                                        }

                                                        {
                                                            showWithdrawModal && animationState === null && ( <
                                                                div className = "fixed inset-0 bg-black/80 z-50 flex items-end justify-center" >
                                                                <
                                                                div className = "w-full max-w-md bg-neutral-950 border-t border-white/10 rounded-t-[32px] p-6 space-y-5" >
                                                                <
                                                                div className = "flex justify-between items-center" >
                                                                <
                                                                h3 className = "text-xl font-bold text-white" > Withdraw
                                                                funds < /h3> <
                                                                button onClick = { () => setShowWithdrawModal(false) }
                                                                className = "w-8 h-8 rounded-full bg-neutral-900 flex items-center justify-center text-neutral-400" >
                                                                <
                                                                span className = "material-symbols-rounded text-sm" >
                                                                close < /span> <
                                                                /button> <
                                                                /div> <
                                                                div className = "orange-gradient p-5 rounded-2xl flex justify-between items-center shadow-lg"
                                                                style = { { background: `linear-gradient(135deg, ${branding.primaryColor}, ${branding.accentColor})` } } >
                                                                <
                                                                div >
                                                                <
                                                                p className = "text-[11px] uppercase tracking-wider text-white/80 font-medium" >
                                                                Available balance < /p> <
                                                                h2 className = "text-3xl font-black text-white mt-0.5" >
                                                                ₹ { walletBalance.toFixed(2) } < /h2> <
                                                                /div> <
                                                                div className = "bg-black/20 px-3 py-1.5 rounded-xl flex items-center space-x-1 text-xs font-semibold text-white" >
                                                                <
                                                                span className = "material-symbols-rounded text-sm" >
                                                                account_balance_wallet < /span> <
                                                                span > Wallet < /span> <
                                                                /div> <
                                                                /div> <
                                                                div className = "space-y-2" >
                                                                <
                                                                label className = "text-xs uppercase tracking-wider text-brand-grayMuted font-bold" >
                                                                Payment Method < /label> <
                                                                div className = "grid grid-cols-2 gap-3" >
                                                                <
                                                                div onClick = { () => setWithdrawalMethod('UPI') }
                                                                className = { `cursor-pointer p-4 rounded-xl flex flex-col justify-between h-20 border-2 transition ${withdrawalMethod === 'UPI' ? 'border-brand-orange bg-brand-orange/5 text-brand-orange' : 'border-white/5 bg-neutral-900 text-neutral-400'}` } >
                                                                <
                                                                span className = "material-symbols-rounded" > smartphone <
                                                                /span> <
                                                                span className = "text-xs font-bold text-white" > UPI
                                                                Transfer < /span> <
                                                                /div> <
                                                                div onClick = { () => setWithdrawalMethod('REDEEM') }
                                                                className = { `cursor-pointer p-4 rounded-xl flex flex-col justify-between h-20 border-2 transition ${withdrawalMethod === 'REDEEM' ? 'border-brand-orange bg-brand-orange/5 text-brand-orange' : 'border-white/5 bg-neutral-900 text-neutral-400'}` } >
                                                                <
                                                                span className = "material-symbols-rounded" >
                                                                confirmation_number < /span> <
                                                                span className = "text-xs font-bold text-white" > Redeem
                                                                Code < /span> <
                                                                /div> <
                                                                /div> <
                                                                /div> <
                                                                div className = "bg-neutral-900/60 p-4 rounded-xl flex items-center justify-between border border-white/5" >
                                                                <
                                                                div className = "flex items-center space-x-3" >
                                                                <
                                                                span className = "material-symbols-rounded text-brand-orange" >
                                                                { withdrawalMethod === 'UPI' ? 'account_circle' :
                                                                    'alternate_email' } < /span> <
                                                                div >
                                                                <
                                                                p className = "text-[10px] text-brand-grayMuted" > {
                                                                    withdrawalMethod === 'UPI' ?
                                                                    'Registered UPI Destination ID' :
                                                                    'Code delivery target email' } < /p> <
                                                                p className = "text-xs font-bold text-white font-mono" > {
                                                                    withdrawalMethod === 'UPI' ? (payoutAccounts.upiId ||
                                                                        'Not Setup Yet') : (payoutAccounts
                                                                        .redeemEmail || 'Not Setup Yet') } < /p> <
                                                                /div> <
                                                                /div> <
                                                                /div> <
                                                                div className = "space-y-2" >
                                                                <
                                                                label className = "text-xs uppercase tracking-wider text-brand-grayMuted font-bold" >
                                                                Select Amount < /label> <
                                                                div className = "grid grid-cols-4 gap-2" > {
                                                                    ['10', '20', '50', '100'].map((amt) => ( <
                                                                        button key = { amt }
                                                                        onClick = { () => setSelectedAmount(amt) }
                                                                        className = { `py-2.5 rounded-xl font-mono text-sm font-bold border text-center transition ${selectedAmount === amt ? 'border-brand-orange bg-brand-orange/10 text-brand-orange' : 'border-white/10 bg-neutral-900 text-neutral-400'}` } >
                                                                        ₹ { amt } <
                                                                        /button>
                                                                    ))
                                                                } <
                                                                /div> <
                                                                /div> <
                                                                div className = "grid grid-cols-2 gap-3 pt-2" >
                                                                <
                                                                button onClick = { () => setShowWithdrawModal(false) }
                                                                className = "py-3.5 rounded-xl bg-neutral-900 border border-white/5 text-neutral-300 text-sm font-bold" >
                                                                Cancel < /button> <
                                                                button onClick = { triggerWithdrawal }
                                                                className = { `py-3.5 rounded-xl text-white text-sm font-bold shadow-md transition ${selectedAmount ? 'orange-gradient opacity-100' : 'bg-neutral-800 opacity-50 cursor-not-allowed'}` }
                                                                style = { selectedAmount ? { background: `linear-gradient(135deg, ${branding.primaryColor}, ${branding.accentColor})` } :
                                                                {} } >
                                                                Proceed < /button> <
                                                                /div> <
                                                                /div> <
                                                                /div>
                                                            )
                                                        }

                                                        {
                                                            showTermsModal && ( <
                                                                div className = "fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4" >
                                                                <
                                                                div className = "w-full max-w-md bg-neutral-950 border border-white/10 rounded-2xl flex flex-col max-h-[80vh]" >
                                                                <
                                                                div className = "flex justify-between items-center p-4 border-b border-white/5" >
                                                                <
                                                                h3 className = "text-md font-bold text-white" > Terms &
                                                                Conditions < /h3> <
                                                                button onClick = { () => setShowTermsModal(false) }
                                                                className = "w-8 h-8 rounded-full bg-neutral-900 flex items-center justify-center text-neutral-400" >
                                                                <
                                                                span className = "material-symbols-rounded text-sm" >
                                                                close < /span> <
                                                                /button> <
                                                                /div> <
                                                                div className = "flex-1 overflow-y-auto p-4 space-y-4 text-xs text-neutral-300 leading-relaxed no-scrollbar" >
                                                                <
                                                                p className = "font-bold text-brand-orange" > Effective
                                                                Date: July 12, 2026 < /p> <
                                                                p > Welcome to Reward Rush.By running this system node,
                                                                you explicitly agree to all terms here. < /p> <
                                                                h4 className = "font-bold text-white uppercase mt-2" > 1.
                                                                PLATFORM COMPLIANCE < /h4> <
                                                                p > • Only single individual node allocation registries
                                                                are supported.Multi - routing behavior triggers server
                                                                closures. < /p> <
                                                                h4 className = "font-bold text-white uppercase mt-2" > 2.
                                                                REWARD EXTRACTION < /h4> <
                                                                p > • All reward amounts are subject to verification
                                                                before final disbursement. < /p> <
                                                                p > • Any attempt to manipulate the system will result in
                                                                immediate termination of node access. < /p> <
                                                                h4 className = "font-bold text-white uppercase mt-2" > 3.
                                                                PRIVACY & DATA < /h4> <
                                                                p > • Your data is encrypted and stored securely in
                                                                compliance with standard protocols. < /p> <
                                                                p > • We do not share your personal information with
                                                                third - party entities without explicit consent. < /p> <
                                                                h4 className = "font-bold text-white uppercase mt-2" > 4.
                                                                WITHDRAWAL POLICY < /h4> <
                                                                p > • Minimum withdrawal amount is ₹10.Payments are
                                                                processed within 24 - 48 hours. < /p> <
                                                                p > • UPI and Redeem Code options are available for
                                                                payout. < /p> <
                                                                /div> <
                                                                div className = "p-3 bg-neutral-900 border-t border-white/5 text-center" >
                                                                <
                                                                button onClick = { () => setShowTermsModal(false) }
                                                                className = "px-6 py-2 rounded-xl orange-gradient text-xs font-bold text-white" >
                                                                I Agree < /button> <
                                                                /div> <
                                                                /div> <
                                                                /div>
                                                            )
                                                        }

                                                        {
                                                            animationState === null && ( <
                                                                div className = "fixed bottom-0 left-0 right-0 mx-auto max-w-md glass-panel flex justify-around items-center py-3 z-40" >
                                                                <
                                                                BottomTabItem icon = "task_alt"
                                                                label = "Tasks"
                                                                active = { activeTab === 'TASKS' && profileSubView ===
                                                                null }
                                                                onClick = {
                                                                    () => { setActiveTab('TASKS');
                                                                        setProfileSubView(null); } }
                                                                /> <
                                                                BottomTabItem icon = "casino"
                                                                label = "Offers"
                                                                active = { activeTab === 'OFFERS' && profileSubView ===
                                                                null }
                                                                onClick = {
                                                                    () => { setActiveTab('OFFERS');
                                                                        setProfileSubView(null); } }
                                                                /> <
                                                                BottomTabItem icon = "history"
                                                                label = "Logs"
                                                                active = { activeTab === 'TRANSACTIONS' &&
                                                                    profileSubView === null }
                                                                onClick = {
                                                                    () => { setActiveTab('TRANSACTIONS');
                                                                        setProfileSubView(null); } }
                                                                /> <
                                                                BottomTabItem icon = "assignment"
                                                                label = "Surveys"
                                                                active = { activeTab === 'SARVES' && profileSubView ===
                                                                null }
                                                                onClick = {
                                                                    () => { setActiveTab('SARVES');
                                                                        setProfileSubView(null); } }
                                                                /> <
                                                                BottomTabItem icon = "person"
                                                                label = "Profile"
                                                                active = { activeTab === 'PROFILE' && profileSubView ===
                                                                null }
                                                                onClick = {
                                                                    () => { setActiveTab('PROFILE');
                                                                        setProfileSubView(null); } }
                                                                /> <
                                                                /div>
                                                            )
                                                        } <
                                                        /div>
                                                    );
                                                }

                                                                        /* ─── MOUNT ─── */
                                                                        const root = ReactDOM.createRoot(document
                                                                            .getElementById('app-root'));
                                                                        root.render( < RewardRushApp / > );
