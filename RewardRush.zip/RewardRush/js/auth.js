/* ============================================================
   FILE: js/auth.js
   Firebase Authentication helpers used by RewardRushApp
   (js/app.js). Extracted from the original handleAuthAction /
   handleGoogleSignIn / logoutUser handlers — same Firebase Auth
   calls, same behaviour, just reusable top-level functions so
   app.js stays focused on state + rendering.
   ============================================================ */

/* Email/password login or registration. Throws on failure so the
   caller can show its own alert/UI state. */
async function authEmailPasswordAction(isRegisterMode, email, password) {
    const { createUserWithEmailAndPassword, signInWithEmailAndPassword } = await import(
        "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js");
    if (isRegisterMode) {
        await createUserWithEmailAndPassword(authInstance, email, password);
    } else {
        await signInWithEmailAndPassword(authInstance, email, password);
    }
}

/* Google popup sign-in. */
async function authGoogleSignIn() {
    const { GoogleAuthProvider, signInWithPopup } = await import(
        "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js");
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    await signInWithPopup(authInstance, provider);
}

/* Sign the current user out. */
async function authLogout() {
    const { signOut } = await import(
        "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js");
    await signOut(authInstance);
}

/* Returns a fresh Firebase ID token for the current user, used to
   authenticate calls to the Netlify Functions backend (withdraw,
   etc). Returns null if nobody is signed in. */
async function authGetIdToken() {
    const user = authInstance && authInstance.currentUser;
    if (!user) return null;
    return await user.getIdToken();
}
