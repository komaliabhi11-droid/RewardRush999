/* React hooks, made available as bare globals for every js/*.js
   file loaded after this one (same as the original single-file
   app, which destructured these once at the top of its one
   <script> tag). */
const { useState, useRef, useEffect, useCallback, useMemo } = React;

/* ============================================================
   FILE: js/firebase.js
   Firebase Web SDK config + shared instances.

   NOTE: this app uses the Firebase Realtime Database (not
   Firestore) — that is what the original single-file app used
   throughout (users/, transactions/, offers/, branding/,
   notifications/ nodes). To avoid breaking any existing feature
   or data, this project keeps using the Realtime Database
   end-to-end (client SDK here, firebase-admin Realtime Database
   API in the Netlify functions).

   This config object is the public Firebase *web* config. It is
   safe to ship in client-side code (Firebase web configs are not
   secret — access is controlled by Firebase Auth + Database
   Security Rules, see database.rules.json). Server-side secrets
   (service account credentials, CPX secure hash) live only in
   Netlify Environment Variables and are never sent to the browser.
   ============================================================ */

const firebaseConfig = {
    apiKey: "AIzaSyDkZ4R9b1aiSE3a8Hv_aenQdtulMbIbIQw",
    authDomain: "mr-earning-a806d.firebaseapp.com",
    databaseURL: "https://mr-earning-a806d-default-rtdb.firebaseio.com",
    projectId: "mr-earning-a806d",
    storageBucket: "mr-earning-a806d.firebasestorage.app",
    messagingSenderId: "139526163112",
    appId: "1:139526163112:web:eada4fcdf54a815bb6d09d"
};

/* Shared Firebase Auth / Database instances, populated once
   Firebase finishes initializing inside app.js's useEffect.
   Declared here at top-level script scope so every other
   js/*.js file (loaded after this one) can read/write them. */
let authInstance = null;
let dbInstance = null;

/* CPX Research app id (public - it's embedded in the CPX widget
   script on the client already, matches the value that was
   hardcoded in the original SarvesTab component). */
const CPX_APP_ID = 34407;

function generateReferralCode(length = 6) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < length; i++) result += chars.charAt(Math.floor(Math.random() * chars.length));
    return 'RR' + result;
}
