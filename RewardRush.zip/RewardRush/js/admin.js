/* ============================================================
   FILE: js/admin.js

   NOTE FOR THE PROJECT OWNER: the uploaded index.html did not
   contain an admin panel anywhere in its code, so there was
   nothing existing to reuse here. This is a new, fully working
   admin panel built with the exact same design system (colors,
   glass-card / orange-gradient classes, fonts) as the rest of the
   app so it looks native to Reward Rush. It talks only to
   netlify/functions/admin.js. If you already have a separate
   admin panel elsewhere, just don't deploy this page — it lives
   entirely in its own admin.html and never touches index.html.
   ============================================================ */

function AdminApp() {
    const [firebaseReady, setFirebaseReady] = useState(false);
    const [user, setUser] = useState(null);
    const [adminKey, setAdminKey] = useState(sessionStorage.getItem('rr_admin_key') || '');
    const [authorized, setAuthorized] = useState(false);
    const [authError, setAuthError] = useState('');
    const [loginEmail, setLoginEmail] = useState('');
    const [loginPassword, setLoginPassword] = useState('');
    const [tab, setTab] = useState('WITHDRAWALS');
    const [withdrawals, setWithdrawals] = useState([]);
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(false);
    const [notifTitle, setNotifTitle] = useState('');
    const [notifMessage, setNotifMessage] = useState('');
    const [notifTarget, setNotifTarget] = useState('');
    const [coinUid, setCoinUid] = useState('');
    const [coinAmount, setCoinAmount] = useState('');
    const [coinReason, setCoinReason] = useState('');

    useEffect(() => {
        let mounted = true;
        (async () => {
            const { initializeApp } = await import("https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js");
            const { getAuth, onAuthStateChanged } = await import("https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js");
            const app = initializeApp(firebaseConfig);
            authInstance = getAuth(app);
            if (!mounted) return;
            setFirebaseReady(true);
            onAuthStateChanged(authInstance, (u) => {
                if (!mounted) return;
                setUser(u);
                if (u && adminKey) verifyAndLoad(u, adminKey);
            });
        })();
        return () => { mounted = false; };
    }, []);

    async function callAdmin(action, extra) {
        const idToken = await authGetIdToken();
        const res = await fetch('/.netlify/functions/admin', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + idToken,
                'x-admin-key': adminKey
            },
            body: JSON.stringify({ action, ...extra })
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || !data.success) throw new Error(data.error || `Request failed (${res.status})`);
        return data;
    }

    async function verifyAndLoad(currentUser, key) {
        setLoading(true);
        setAuthError('');
        try {
            const data = await callAdminWith(currentUser, key, 'listWithdrawals', {});
            setWithdrawals(data.withdrawals || []);
            setAuthorized(true);
            sessionStorage.setItem('rr_admin_key', key);
        } catch (err) {
            setAuthorized(false);
            setAuthError(err.message);
        } finally {
            setLoading(false);
        }
    }

    async function callAdminWith(currentUser, key, action, extra) {
        const idToken = await currentUser.getIdToken();
        const res = await fetch('/.netlify/functions/admin', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + idToken, 'x-admin-key': key },
            body: JSON.stringify({ action, ...extra })
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || !data.success) throw new Error(data.error || `Request failed (${res.status})`);
        return data;
    }

    const handleLogin = async (e) => {
        e.preventDefault();
        setAuthError('');
        try {
            await authEmailPasswordAction(false, loginEmail, loginPassword);
        } catch (err) {
            setAuthError(err.message);
        }
    };

    const handleKeySubmit = (e) => {
        e.preventDefault();
        if (user) verifyAndLoad(user, adminKey);
    };

    const refreshWithdrawals = async () => {
        setLoading(true);
        try {
            const data = await callAdmin('listWithdrawals');
            setWithdrawals(data.withdrawals || []);
        } catch (err) { alert(err.message); }
        finally { setLoading(false); }
    };

    const refreshUsers = async () => {
        setLoading(true);
        try {
            const data = await callAdmin('listUsers');
            setUsers(data.users || []);
        } catch (err) { alert(err.message); }
        finally { setLoading(false); }
    };

    useEffect(() => {
        if (authorized && tab === 'USERS' && users.length === 0) refreshUsers();
    }, [authorized, tab]);

    const approve = async (id) => {
        if (!confirm('Approve this withdrawal?')) return;
        try { await callAdmin('approveWithdrawal', { withdrawalId: id }); refreshWithdrawals(); }
        catch (err) { alert(err.message); }
    };

    const reject = async (id) => {
        const reason = prompt('Reason for rejection (optional):') || '';
        try { await callAdmin('rejectWithdrawal', { withdrawalId: id, reason }); refreshWithdrawals(); }
        catch (err) { alert(err.message); }
    };

    const sendNotification = async (e) => {
        e.preventDefault();
        if (!notifTitle || !notifMessage) return;
        try {
            await callAdmin('sendNotification', { title: notifTitle, message: notifMessage, target: notifTarget || null });
            alert('Notification sent!');
            setNotifTitle(''); setNotifMessage(''); setNotifTarget('');
        } catch (err) { alert(err.message); }
    };

    const adjustCoins = async (direction) => {
        if (!coinUid || !coinAmount) return;
        try {
            await callAdmin(direction === 'add' ? 'addCoins' : 'removeCoins', {
                uid: coinUid, amount: parseFloat(coinAmount), reason: coinReason
            });
            alert('Balance updated!');
            setCoinAmount(''); setCoinReason('');
            refreshUsers();
        } catch (err) { alert(err.message); }
    };

    if (!firebaseReady) {
        return <div className="min-h-screen bg-brand-black flex items-center justify-center text-neutral-500 text-sm">Loading…</div>;
    }

    if (!user) {
        return (
            <div className="mx-auto max-w-md min-h-screen bg-brand-black flex flex-col justify-center px-6 py-8 border-x border-neutral-900">
                <h1 className="text-2xl font-black text-white mb-1">Reward Rush Admin</h1>
                <p className="text-xs text-brand-grayMuted mb-6">Sign in with your admin Firebase account.</p>
                <form onSubmit={handleLogin} className="space-y-3">
                    <input className="w-full bg-neutral-900 rounded-xl px-4 py-3 text-sm text-white outline-none border border-white/5"
                        placeholder="Admin email" value={loginEmail} onChange={e => setLoginEmail(e.target.value)} />
                    <input className="w-full bg-neutral-900 rounded-xl px-4 py-3 text-sm text-white outline-none border border-white/5"
                        type="password" placeholder="Password" value={loginPassword} onChange={e => setLoginPassword(e.target.value)} />
                    <button className="w-full py-3 rounded-xl orange-gradient text-white text-sm font-bold">Sign In</button>
                    {authError && <p className="text-xs text-red-400 mt-2">{authError}</p>}
                </form>
            </div>
        );
    }

    if (!authorized) {
        return (
            <div className="mx-auto max-w-md min-h-screen bg-brand-black flex flex-col justify-center px-6 py-8 border-x border-neutral-900">
                <h1 className="text-2xl font-black text-white mb-1">Admin Key Required</h1>
                <p className="text-xs text-brand-grayMuted mb-6">Signed in as {user.email}. Enter the ADMIN_API_KEY configured in Netlify to continue.</p>
                <form onSubmit={handleKeySubmit} className="space-y-3">
                    <input className="w-full bg-neutral-900 rounded-xl px-4 py-3 text-sm text-white outline-none border border-white/5"
                        type="password" placeholder="Admin API key" value={adminKey} onChange={e => setAdminKey(e.target.value)} />
                    <button disabled={loading} className="w-full py-3 rounded-xl orange-gradient text-white text-sm font-bold disabled:opacity-50">
                        {loading ? 'Verifying…' : 'Continue'}
                    </button>
                    {authError && <p className="text-xs text-red-400 mt-2">{authError}</p>}
                </form>
                <button onClick={() => authLogout()} className="text-xs text-neutral-500 mt-6 underline">Sign out</button>
            </div>
        );
    }

    return (
        <div className="mx-auto max-w-3xl min-h-screen bg-brand-black px-4 py-6 border-x border-neutral-900">
            <div className="flex justify-between items-center mb-6">
                <div>
                    <h1 className="text-xl font-black text-white">Reward Rush Admin</h1>
                    <p className="text-[11px] text-brand-grayMuted">{user.email}</p>
                </div>
                <button onClick={() => authLogout()} className="text-xs px-3 py-1.5 rounded-full bg-neutral-900 border border-white/5 text-neutral-300">Sign out</button>
            </div>

            <div className="flex space-x-2 mb-6 overflow-x-auto no-scrollbar">
                {['WITHDRAWALS', 'USERS', 'NOTIFY'].map(t => (
                    <button key={t} onClick={() => setTab(t)}
                        className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap ${tab === t ? 'orange-gradient text-white' : 'bg-neutral-900 text-neutral-400 border border-white/5'}`}>
                        {t === 'WITHDRAWALS' ? 'Withdrawals' : t === 'USERS' ? 'Users & Coins' : 'Send Notification'}
                    </button>
                ))}
            </div>

            {tab === 'WITHDRAWALS' && (
                <div className="space-y-3">
                    <div className="flex justify-between items-center">
                        <h2 className="text-sm font-bold text-white">Pending & recent withdrawals</h2>
                        <button onClick={refreshWithdrawals} className="text-xs text-brand-orange">{loading ? 'Loading…' : 'Refresh'}</button>
                    </div>
                    {withdrawals.length === 0 && <p className="text-xs text-neutral-500">No withdrawals yet.</p>}
                    {withdrawals.map(w => (
                        <div key={w.id} className="glass-card p-4 rounded-2xl space-y-1">
                            <div className="flex justify-between text-sm text-white font-bold">
                                <span>₹{w.amount}</span>
                                <span className={`text-[10px] px-2 py-0.5 rounded-full ${w.status === 'PENDING' ? 'bg-amber-500/20 text-amber-400' : w.status === 'APPROVED' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>{w.status}</span>
                            </div>
                            <p className="text-[11px] text-neutral-400">{w.fullName} · {w.upiId} · {w.phone}</p>
                            <p className="text-[10px] text-neutral-600">uid: {w.uid}</p>
                            {w.status === 'PENDING' && (
                                <div className="flex space-x-2 pt-2">
                                    <button onClick={() => approve(w.id)} className="flex-1 py-2 rounded-lg bg-green-600/20 text-green-400 text-xs font-bold">Approve</button>
                                    <button onClick={() => reject(w.id)} className="flex-1 py-2 rounded-lg bg-red-600/20 text-red-400 text-xs font-bold">Reject</button>
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            )}

            {tab === 'USERS' && (
                <div className="space-y-6">
                    <div className="glass-card p-4 rounded-2xl space-y-3">
                        <h2 className="text-sm font-bold text-white">Add / remove coins</h2>
                        <input className="w-full bg-neutral-900 rounded-xl px-4 py-2.5 text-xs text-white outline-none border border-white/5"
                            placeholder="User UID" value={coinUid} onChange={e => setCoinUid(e.target.value)} />
                        <input className="w-full bg-neutral-900 rounded-xl px-4 py-2.5 text-xs text-white outline-none border border-white/5"
                            type="number" placeholder="Amount (₹)" value={coinAmount} onChange={e => setCoinAmount(e.target.value)} />
                        <input className="w-full bg-neutral-900 rounded-xl px-4 py-2.5 text-xs text-white outline-none border border-white/5"
                            placeholder="Reason (optional)" value={coinReason} onChange={e => setCoinReason(e.target.value)} />
                        <div className="flex space-x-2">
                            <button onClick={() => adjustCoins('add')} className="flex-1 py-2.5 rounded-lg orange-gradient text-white text-xs font-bold">Add Coins</button>
                            <button onClick={() => adjustCoins('remove')} className="flex-1 py-2.5 rounded-lg bg-neutral-800 text-white text-xs font-bold border border-white/10">Remove Coins</button>
                        </div>
                    </div>

                    <div className="flex justify-between items-center">
                        <h2 className="text-sm font-bold text-white">All users</h2>
                        <button onClick={refreshUsers} className="text-xs text-brand-orange">{loading ? 'Loading…' : 'Refresh'}</button>
                    </div>
                    <div className="space-y-2">
                        {users.map(u => (
                            <div key={u.uid} className="glass-card p-3 rounded-xl flex justify-between items-center">
                                <div>
                                    <p className="text-xs text-white font-bold">{u.fullName || '(no name)'}</p>
                                    <p className="text-[10px] text-neutral-500">{u.email} · {u.uid}</p>
                                </div>
                                <span className="text-sm font-bold text-brand-orange">₹{u.balance}</span>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {tab === 'NOTIFY' && (
                <form onSubmit={sendNotification} className="glass-card p-4 rounded-2xl space-y-3">
                    <h2 className="text-sm font-bold text-white">Send notification</h2>
                    <input className="w-full bg-neutral-900 rounded-xl px-4 py-2.5 text-xs text-white outline-none border border-white/5"
                        placeholder="Title" value={notifTitle} onChange={e => setNotifTitle(e.target.value)} />
                    <textarea className="w-full bg-neutral-900 rounded-xl px-4 py-2.5 text-xs text-white outline-none border border-white/5"
                        placeholder="Message" rows={3} value={notifMessage} onChange={e => setNotifMessage(e.target.value)} />
                    <input className="w-full bg-neutral-900 rounded-xl px-4 py-2.5 text-xs text-white outline-none border border-white/5"
                        placeholder="Target user UID (leave blank to broadcast to everyone)" value={notifTarget} onChange={e => setNotifTarget(e.target.value)} />
                    <button className="w-full py-3 rounded-xl orange-gradient text-white text-sm font-bold">Send</button>
                </form>
            )}
        </div>
    );
}

const adminRoot = ReactDOM.createRoot(document.getElementById('admin-root'));
adminRoot.render(<AdminApp />);
