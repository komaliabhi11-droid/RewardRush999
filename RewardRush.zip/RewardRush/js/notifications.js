/* ============================================================
   FILE: js/notifications.js
   Notification helpers shared by the app + admin panel.

   Notifications live under the `notifications/{id}` Realtime
   Database node (same schema the original app already read from:
   { title, message, createdAt, ... }). Anything pushed there by
   an admin (via netlify/functions/admin.js or admin.html) shows
   up for every signed-in user through the existing onValue
   subscription in app.js.
   ============================================================ */

/* Converts a Realtime Database `notifications` snapshot value
   into a sorted array (newest first) — exact same logic the
   original inline onValue callback used, just reusable. */
function normalizeNotifications(data) {
    if (!data) return [];
    const list = Object.keys(data).map(k => ({ id: k, ...data[k] }));
    list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    return list;
}
