/* ============================================================
   FILE: js/withdraw.js
   Client-side withdrawal helpers used by RewardRushApp.

   The original app wrote the balance deduction + transaction
   record directly from the browser using the Firebase client
   SDK. That is easy to tamper with (a user could edit `amount`
   in devtools and drain more than their real balance). This file
   keeps the exact same UI flow (same modal, same validations,
   same success animation in app.js) but sends the request to the
   secure Netlify function `netlify/functions/withdraw.js`, which
   re-checks the balance server-side with firebase-admin before
   touching the database — closing that gap without changing
   anything the user sees.
   ============================================================ */

/* Same validation the original app performed before opening /
   submitting the withdraw modal — centralised so both call sites
   in app.js stay in sync. */
function isPayoutDetailsComplete(personalDetails, payoutAccounts) {
    return !!(
        personalDetails && personalDetails.fullName && personalDetails.fullName.trim() &&
        personalDetails.phone && personalDetails.phone.trim() &&
        payoutAccounts && payoutAccounts.upiId && payoutAccounts.upiId.trim()
    );
}

/* Submits a withdrawal request to the Netlify backend.
   Returns { success: true, newBalance } on success, or
   { success: false, error } on failure. Never throws. */
async function submitWithdrawalRequest({ amount, method, personalDetails, payoutAccounts }) {
    try {
        const idToken = await authGetIdToken();
        if (!idToken) {
            return { success: false, error: 'You must be signed in to withdraw.' };
        }
        const response = await fetch('/.netlify/functions/withdraw', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + idToken
            },
            body: JSON.stringify({
                amount,
                method,
                upiId: payoutAccounts.upiId,
                fullName: personalDetails.fullName,
                phone: personalDetails.phone
            })
        });
        const data = await response.json();
        if (!response.ok || !data.success) {
            return { success: false, error: data.error || 'Withdrawal request failed.' };
        }
        return { success: true, newBalance: data.newBalance, withdrawalId: data.withdrawalId };
    } catch (err) {
        return { success: false, error: err.message || 'Network error while submitting withdrawal.' };
    }
}
