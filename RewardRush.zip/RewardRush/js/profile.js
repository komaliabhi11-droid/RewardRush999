/* ============================================================
   FILE: js/profile.js
   Profile tab + Personal / Address / Payout detail sub-views.
   ============================================================ */

                                                                /* ─── PROFILE TAB ─── */
                                                                function ProfileTab({ userData, referralCode, referralsCount,
                                                                        referralEarnings, onShare, onNavigate, onOpenTerms,
                                                                        onLogout, accentColor }) {
                                                                    return ( <
                                                                        div className = "space-y-5 pt-2" >
                                                                        <
                                                                        div className = "text-center py-4 space-y-2" >
                                                                        <
                                                                        div className = "w-20 h-20 rounded-full orange-gradient p-0.5 mx-auto relative"
                                                                        style = { { background: `linear-gradient(135deg, ${accentColor}, #FF7A00)` } } >
                                                                        <
                                                                        div className =
                                                                        "w-full h-full rounded-full bg-black flex items-center justify-center overflow-hidden" >
                                                                        {
                                                                            userData.avatarUrl ? < img src = { userData
                                                                                    .avatarUrl }
                                                                                className =
                                                                                "w-full h-full object-cover"
                                                                                alt = "avatar" / >
                                                                                :
                                                                                < span className =
                                                                                "text-xl font-black text-white" >
                                                                                { userData.fullName?.substring(0, 2)
                                                                                    .toUpperCase() || 'UR' } <
                                                                                /span>} <
                                                                                /div> <
                                                                                /div> <
                                                                                div >
                                                                                <
                                                                                h3 className =
                                                                                "text-lg font-bold text-white" >
                                                                                { userData.fullName ||
                                                                                    'New User Setup' } <
                                                                                /h3> <
                                                                                p className =
                                                                                "text-[11px] text-brand-grayMuted" >
                                                                                Configure account metrics below <
                                                                                /p> <
                                                                                /div> <
                                                                                /div> <
                                                                                div className =
                                                                                "glass-card p-4 rounded-xl border border-white/5 bg-gradient-to-r from-orange-500/10 to-amber-500/10" >
                                                                                <
                                                                                div className =
                                                                                "flex justify-between items-center" >
                                                                                <
                                                                                div >
                                                                                <
                                                                                p className =
                                                                                "text-[10px] uppercase tracking-wider text-brand-grayMuted font-bold" >
                                                                                Referral Code < /p> <
                                                                                p className =
                                                                                "text-lg font-mono font-bold"
                                                                                style = { { color: accentColor } } >
                                                                                { referralCode } < /p> <
                                                                                /div> <
                                                                                button onClick = { onShare }
                                                                                className =
                                                                                "p-2 bg-neutral-800 rounded-full hover:bg-neutral-700 transition" >
                                                                                <
                                                                                span className =
                                                                                "material-symbols-rounded"
                                                                                style = { { color: accentColor } } >
                                                                                share < /span> <
                                                                                /button> <
                                                                                div className = "text-right" >
                                                                                <
                                                                                p className =
                                                                                "text-[10px] uppercase tracking-wider text-brand-grayMuted font-bold" >
                                                                                Referrals < /p> <
                                                                                p className =
                                                                                "text-lg font-bold text-white" >
                                                                                { referralsCount } < /p> <
                                                                                /div> <
                                                                                div className = "text-right" >
                                                                                <
                                                                                p className =
                                                                                "text-[10px] uppercase tracking-wider text-brand-grayMuted font-bold" >
                                                                                Earned < /p> <
                                                                                p className =
                                                                                "text-lg font-bold text-emerald-400" >
                                                                                ₹ { referralEarnings } < /p> <
                                                                                /div> <
                                                                                /div> <
                                                                                /div> <
                                                                                div className =
                                                                                "glass-card rounded-xl overflow-hidden divide-y divide-white/5 border border-white/5" >
                                                                                <
                                                                                div onClick = {
                                                                                    () => onNavigate('PERSONAL') }
                                                                                className =
                                                                                "flex items-center justify-between p-4 hover:bg-neutral-900/30 cursor-pointer transition" >
                                                                                <
                                                                                span className =
                                                                                "text-xs font-medium text-neutral-200" >
                                                                                Edit Profile & Avatar Image <
                                                                                /span> <
                                                                                span className =
                                                                                "material-symbols-rounded text-neutral-600 text-sm" >
                                                                                chevron_right < /span> <
                                                                                /div> <
                                                                                div onClick = {
                                                                                    () => onNavigate('ADDRESS') }
                                                                                className =
                                                                                "flex items-center justify-between p-4 hover:bg-neutral-900/30 cursor-pointer transition" >
                                                                                <
                                                                                span className =
                                                                                "text-xs font-medium text-neutral-200" >
                                                                                Address Details < /span> <
                                                                                span className =
                                                                                "material-symbols-rounded text-neutral-600 text-sm" >
                                                                                chevron_right < /span> <
                                                                                /div> <
                                                                                div onClick = {
                                                                                    () => onNavigate('PAYOUT') }
                                                                                className =
                                                                                "flex items-center justify-between p-4 hover:bg-neutral-900/30 cursor-pointer transition" >
                                                                                <
                                                                                span className =
                                                                                "text-xs font-medium text-neutral-200" >
                                                                                Payout & Payment Details <
                                                                                /span> <
                                                                                span className =
                                                                                "material-symbols-rounded text-neutral-600 text-sm" >
                                                                                chevron_right < /span> <
                                                                                /div> <
                                                                                div onClick = { onLogout }
                                                                                className =
                                                                                "flex items-center justify-between p-4 hover:bg-red-500/5 cursor-pointer transition" >
                                                                                <
                                                                                span className =
                                                                                "text-xs font-medium text-red-400" >
                                                                                Disconnect Session Node < /span> <
                                                                                span className =
                                                                                "material-symbols-rounded text-red-400 text-sm" >
                                                                                logout < /span> <
                                                                                /div> <
                                                                                /div> <
                                                                                /div>
                                                                            );
                                                                        }

                                                                        /* ─── PERSONAL DETAILS VIEW ─── */
                                                                        function PersonalDetailsView({ data, onSave,
                                                                            onBack }) {
                                                                            const [name, setName] = useState(data
                                                                                .fullName || '');
                                                                            const [email, setEmail] = useState(data
                                                                                .email || '');
                                                                            const [phone, setPhone] = useState(data
                                                                                .phone || '');
                                                                            const [avatar, setAvatar] = useState(data
                                                                                .avatarUrl || '');
                                                                            const fileRef = useRef(null);

                                                                            const captureImageFile = (e) => {
                                                                                const file = e.target.files[0];
                                                                                if (file) {
                                                                                    const reader = new FileReader();
                                                                                    reader.onloadend = () => {
                                                                                        setAvatar(reader.result);
                                                                                    };
                                                                                    reader.readAsDataURL(file);
                                                                                }
                                                                            };

                                                                            return ( <
                                                                                div className = "space-y-6 pt-4" >
                                                                                <
                                                                                div className =
                                                                                "flex items-center space-x-3 mb-4" >
                                                                                <
                                                                                button onClick = { onBack }
                                                                                className =
                                                                                "material-symbols-rounded text-white p-1 bg-neutral-900 rounded-full" >
                                                                                arrow_back < /button> <
                                                                                h2 className =
                                                                                "text-xl font-bold text-white" >
                                                                                Edit Profile < /h2> <
                                                                                /div> <
                                                                                div className =
                                                                                "flex flex-col items-center space-y-2 pb-2" >
                                                                                <
                                                                                div onClick = {
                                                                                    () => fileRef.current.click() }
                                                                                className =
                                                                                "w-20 h-20 rounded-full border border-white/20 relative cursor-pointer overflow-hidden bg-neutral-900 flex items-center justify-center" >
                                                                                {
                                                                                    avatar ? < img src = { avatar }
                                                                                    className =
                                                                                    "w-full h-full object-cover"
                                                                                    alt = "avatar" / >
                                                                                    :
                                                                                    < span className =
                                                                                    "material-symbols-rounded text-neutral-400 text-2xl" >
                                                                                    add_a_photo < /span>} <
                                                                                    /div> <
                                                                                    input type = "file"
                                                                                    accept = "image/*"
                                                                                    ref = { fileRef }
                                                                                    onChange = { captureImageFile }
                                                                                    className = "hidden" / >
                                                                                    <
                                                                                    span className =
                                                                                    "text-[10px] text-brand-orangeLight font-medium" >
                                                                                    Click image area to change
                                                                                    avatar image < /span> <
                                                                                    /div> <
                                                                                    div className = "space-y-4" >
                                                                                    <
                                                                                    div className =
                                                                                    "bg-neutral-900/40 p-4 rounded-xl border border-white/5 space-y-1" >
                                                                                    <
                                                                                    label className =
                                                                                    "text-[10px] text-brand-grayMuted uppercase font-bold" >
                                                                                    Full Name < /label> <
                                                                                    input className =
                                                                                    "w-full bg-transparent text-sm font-medium text-white outline-none"
                                                                                    value = { name }
                                                                                    onChange = { (e) => setName(e
                                                                                        .target.value) }
                                                                                    placeholder =
                                                                                    "Enter full name" / >
                                                                                    <
                                                                                    /div> <
                                                                                    div className =
                                                                                    "bg-neutral-900/40 p-4 rounded-xl border border-white/5 space-y-1 opacity-70" >
                                                                                    <
                                                                                    label className =
                                                                                    "text-[10px] text-brand-grayMuted uppercase font-bold" >
                                                                                    Email Address < /label> <
                                                                                    input className =
                                                                                    "w-full bg-transparent text-sm font-medium text-neutral-400 outline-none"
                                                                                    value = { email }
                                                                                    disabled / >
                                                                                    <
                                                                                    /div> <
                                                                                    div className =
                                                                                    "bg-neutral-900/40 p-4 rounded-xl border border-white/5 space-y-1" >
                                                                                    <
                                                                                    label className =
                                                                                    "text-[10px] text-brand-grayMuted uppercase font-bold" >
                                                                                    Phone Number < /label> <
                                                                                    input className =
                                                                                    "w-full bg-transparent text-sm font-medium text-white outline-none"
                                                                                    value = { phone }
                                                                                    onChange = { (e) => setPhone(e
                                                                                        .target.value) }
                                                                                    placeholder =
                                                                                    "Enter contact number" / >
                                                                                    <
                                                                                    /div> <
                                                                                    /div> <
                                                                                    button onClick = {
                                                                                        () => onSave({ fullName: name,
                                                                                            email, phone,
                                                                                            avatarUrl: avatar }) }
                                                                                    className =
                                                                                    "w-full py-4 rounded-xl orange-gradient text-white text-sm font-bold shadow-md" >
                                                                                    Save Changes < /button> <
                                                                                    /div>
                                                                                );
                                                                            }

                                                                        /* ─── ADDRESS DETAILS VIEW ─── */
                                                                        function AddressDetailsView({ data, onSave,
                                                                            onBack }) {
                                                                            const [line, setLine] = useState(data.line ||
                                                                                '');
                                                                            const [stateName, setStateName] = useState(
                                                                                data.state || '');

                                                                            return ( <
                                                                                div className = "space-y-6 pt-4" >
                                                                                <
                                                                                div className =
                                                                                "flex items-center space-x-3 mb-4" >
                                                                                <
                                                                                button onClick = { onBack }
                                                                                className =
                                                                                "material-symbols-rounded text-white p-1 bg-neutral-900 rounded-full" >
                                                                                arrow_back < /button> <
                                                                                h2 className =
                                                                                "text-xl font-bold text-white" >
                                                                                Address Details < /h2> <
                                                                                /div> <
                                                                                div className = "space-y-4" >
                                                                                <
                                                                                div className =
                                                                                "bg-neutral-900/40 p-4 rounded-xl border border-white/5 space-y-1" >
                                                                                <
                                                                                label className =
                                                                                "text-[10px] text-brand-grayMuted uppercase font-bold" >
                                                                                Address Line < /label> <
                                                                                input className =
                                                                                "w-full bg-transparent text-sm font-medium text-white outline-none"
                                                                                value = { line }
                                                                                onChange = { (e) => setLine(e
                                                                                    .target.value) }
                                                                                placeholder = "Street name" / >
                                                                                <
                                                                                /div> <
                                                                                div className =
                                                                                "bg-neutral-900/40 p-4 rounded-xl border border-white/5 space-y-1" >
                                                                                <
                                                                                label className =
                                                                                "text-[10px] text-brand-grayMuted uppercase font-bold" >
                                                                                State < /label> <
                                                                                input className =
                                                                                "w-full bg-transparent text-sm font-medium text-white outline-none"
                                                                                value = { stateName }
                                                                                onChange = { (e) => setStateName(e
                                                                                    .target.value) }
                                                                                placeholder = "State" / >
                                                                                <
                                                                                /div> <
                                                                                /div> <
                                                                                button onClick = {
                                                                                    () => onSave({ line,
                                                                                        state: stateName }) }
                                                                                className =
                                                                                "w-full py-4 rounded-xl orange-gradient text-white text-sm font-bold shadow-md" >
                                                                                Save Address Details < /button> <
                                                                                /div>
                                                                            );
                                                                        }

                                                                        /* ─── PAYOUT DETAILS VIEW ─── */
                                                                        function PayoutDetailsView({ data, onSave,
                                                                            onBack }) {
                                                                            const [name, setName] = useState(data.name ||
                                                                                '');
                                                                            const [email, setEmail] = useState(data
                                                                                .email || '');
                                                                            const [phone, setPhone] = useState(data
                                                                                .phone || '');
                                                                            const [upi, setUpi] = useState(data.payout
                                                                                .upiId || '');
                                                                            const [emailCode, setEmailCode] = useState(
                                                                                data.payout.redeemEmail || '');

                                                                            const handleFormSubmit = () => {
                                                                                if (!name.trim()) { alert(
                                                                                        "Full Name is required.");
                                                                                    return; }
                                                                                if (!email.trim()) { alert(
                                                                                        "Email Address is required."
                                                                                        );
                                                                                    return; }
                                                                                if (!phone.trim()) { alert(
                                                                                        "Mobile Number is required."
                                                                                        );
                                                                                    return; }
                                                                                if (!upi.trim()) { alert(
                                                                                        "Please update your UPI ID to continue withdrawals."
                                                                                        );
                                                                                    return; }
                                                                                onSave({
                                                                                    fullName: name,
                                                                                    email: email,
                                                                                    phone: phone,
                                                                                    payout: { upiId: upi,
                                                                                        redeemEmail: emailCode }
                                                                                });
                                                                            };

                                                                            return ( <
                                                                                div className = "space-y-6 pt-4" >
                                                                                <
                                                                                div className =
                                                                                "flex items-center space-x-3 mb-4" >
                                                                                <
                                                                                button onClick = { onBack }
                                                                                className =
                                                                                "material-symbols-rounded text-white p-1 bg-neutral-900 rounded-full" >
                                                                                arrow_back < /button> <
                                                                                h2 className =
                                                                                "text-xl font-bold text-white" >
                                                                                Payment Details < /h2> <
                                                                                /div> <
                                                                                div className = "space-y-4" >
                                                                                <
                                                                                div className =
                                                                                "bg-neutral-900/40 p-4 rounded-xl border border-white/5 space-y-1" >
                                                                                <
                                                                                label className =
                                                                                "text-[10px] text-brand-grayMuted uppercase font-bold" >
                                                                                Full Name < /label> <
                                                                                input className =
                                                                                "w-full bg-transparent text-sm font-medium text-white outline-none"
                                                                                value = { name }
                                                                                onChange = { (e) => setName(e
                                                                                    .target.value) }
                                                                                placeholder =
                                                                                "Enter full name" / >
                                                                                <
                                                                                /div> <
                                                                                div className =
                                                                                "bg-neutral-900/40 p-4 rounded-xl border border-white/5 space-y-1" >
                                                                                <
                                                                                label className =
                                                                                "text-[10px] text-brand-grayMuted uppercase font-bold" >
                                                                                Email Address < /label> <
                                                                                input className =
                                                                                "w-full bg-transparent text-sm font-medium text-white outline-none"
                                                                                value = { email }
                                                                                onChange = { (e) => setEmail(e
                                                                                    .target.value) }
                                                                                placeholder =
                                                                                "Enter email address" / >
                                                                                <
                                                                                /div> <
                                                                                div className =
                                                                                "bg-neutral-900/40 p-4 rounded-xl border border-white/5 space-y-1" >
                                                                                <
                                                                                label className =
                                                                                "text-[10px] text-brand-grayMuted uppercase font-bold" >
                                                                                Mobile Number < /label> <
                                                                                input className =
                                                                                "w-full bg-transparent text-sm font-medium text-white outline-none"
                                                                                value = { phone }
                                                                                onChange = { (e) => setPhone(e
                                                                                    .target.value) }
                                                                                placeholder =
                                                                                "Enter mobile number" / >
                                                                                <
                                                                                /div> <
                                                                                div className =
                                                                                "glass-card p-4 rounded-2xl border border-white/10 bg-neutral-900/40" >
                                                                                <
                                                                                h4 className =
                                                                                "text-xs font-bold text-white" >
                                                                                UPI ID < /h4> <
                                                                                input className =
                                                                                "w-full bg-transparent font-medium text-neutral-300 text-xs outline-none mt-0.5"
                                                                                value = { upi }
                                                                                onChange = { (e) => setUpi(e
                                                                                    .target.value) }
                                                                                placeholder = "example@upi" / >
                                                                                <
                                                                                /div> <
                                                                                div className =
                                                                                "glass-card p-4 rounded-2xl border border-white/10 bg-neutral-900/40" >
                                                                                <
                                                                                h4 className =
                                                                                "text-xs font-bold text-white" >
                                                                                Redeem Email(Alternative) < /h4> <
                                                                                input className =
                                                                                "w-full bg-transparent font-medium text-neutral-300 text-xs outline-none mt-0.5"
                                                                                value = { emailCode }
                                                                                onChange = { (e) => setEmailCode(e
                                                                                    .target.value) }
                                                                                placeholder = "add your email" / >
                                                                                <
                                                                                /div> <
                                                                                /div> <
                                                                                button onClick = { handleFormSubmit }
                                                                                className =
                                                                                "w-full py-4 rounded-xl orange-gradient text-white text-sm font-bold shadow-md" >
                                                                                Save & Update Details < /button> <
                                                                                /div>
                                                                            );
                                                                        }
